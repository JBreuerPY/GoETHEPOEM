# -*- coding: utf-8 -*-

"""
Dieses Modul enthält Wortlisten und Funktionen zur Analyse von Wörtern durch orthographische Regeln

1) Strings und Listen für später verwendete reguläre Ausdrücke

2) Wortlisten:
- Funktion "readnouns" erstellt:
-- masc_words,fem_words,neut_words,plural_words,sg_nouns

3) Funktionen:
- strip_punctuation
- word_seperator
- get_syllables
- affix_seperator
- get_gender
- get_det
- get_rhyme
- match_rhymes
"""

# re
import re
# choice
from random import choice
# Interpunktion
from string import punctuation

#---------------------------------------#
#                Listen                 #
#---------------------------------------#

#############################################################
# Strings und Listen für später verwendete reguläre Ausdrücke
#############################################################

# Deutsche Präfixe
präfixe = "nieder|wieder|weiter|wider|empor|miss|fort|nach|dar|her|hin|weg|vor|auf|ver|ent|zer|aus|bei|ein|los|mit|ab|an|er|be|ge|da|zu|ur|un"
präfixe_betont = "nieder|wieder|weiter|empor|fort|nach|dar|her|hin|weg|vor|auf|aus|bei|ein|los|mit|ab|an|da|zu|ur|un"
präfixe_unbetont = "ent|ver|zer|be|er|ge"
# Deutsche Suffixe
suffixe = "schaften|schaft|heiten|keiten|lischt|licht|ieren|ungen|nisse|isch|haft|chen|igen|eien|heit|keit|lein|ling|nis|tum|ung|bar|ig|in|ei|er"
suffixe_unbetont = "|schaften|schaft|heiten|keiten|lischt|licht|ungen|nisse|isch|haft|igen|chen|heit|keit|lein|ling|nis|tum|ung|bar|ig|in|en|er"
suffixe_betont = "ieren|eien|ei"
# Phonetische Einheiten
vokale = "ae|ue|oe|ei|au|eu|äu|oy|ie|io|ua|ey|ai|ay|a|e|i|o|u|ä|ö|ü"
konsonanten = "qu|b|c|d|f|g|h|j|k|l|m|n|p|q|r|s|t|v|w|x|y|z|ß"
vokale_liste = ['ae', 'ue', 'oe', 'ei', 'au', 'eu', 'äu', 'oy', 'ie', 'io', 'ey', 'ai', 'ay', 'äh', 'öh', 'üh', 'oh', 'uh', 'ah', 'a', 'e', 'i', 'o', 'u', 'ä', 'ö', 'ü']
kons_stimmhaft = "bdgvw"
kons_stimmlos = "ptkff"
kons_normal = ["f","t","v","f","x","z"]
kons_alternativ = ["ph","th","f","v",["ks","cks","chs"],"ts"]
vok_diph_normal = ["ä","ö","ü","ae","oe","ue","eu","äu","ei","ai"]
vok_diph_alternativ = ["ae","oe","ue","ä","ö","ü","äu","eu","ai","ei"]


"#############################################################################################################"
# read_nouns
"#############################################################################################################"

##############################################################################################
# Funktion zum Einlesen einer Datei, die getaggte Nomen enthält. Ausgegeben werden vier
# Wortlisten mit je maskulinen, femininen, neutralen Nomen, sowie eine Liste mit
# Pluralformen von Nomen.
# Eingabe: txt-Datei
# Ausgabe: Tupel mit Listen (masc_words,fem_words,neut_words, plural_words)
##############################################################################################
def read_nouns(file):
    open_file = open(file, encoding="UTF-8")
    read_file = open_file.read()
    tagged_words = [words.split("\t") for words in read_file.split("\n") if len(words.split("\t")) == 2]
    masc_words = []
    fem_words = []
    neut_words = []
    plural_words = []
    for word in tagged_words:
        if word[1] == "MASC":
            masc_words.append(word[0])
        if word[1] == "FEM":
            fem_words.append(word[0])
        if word[1] == "NEUT":
            neut_words.append(word[0])
        if word[1] == "PL":
            plural_words.append(word[0])
    sg_nouns = masc_words+fem_words+neut_words
            
    return masc_words,fem_words,neut_words,plural_words,sg_nouns

###################################################
# Datei einlesen und Nomen-Wortlisten erstellen #
###################################################

# masc_words,fem_words,neut_words,plural_words erstellen
masc_words,fem_words,neut_words,plural_words,sg_nouns = read_nouns("TaggedNouns.txt")


#----------------------------------------------------#
#        Funktionen für Wörter, bzw. Strings
#----------------------------------------------------#

"###############################################################################################################"
# strip_punctuation
"###############################################################################################################"

#############################################################
# Interpunktion entfernen
# Eingabe: String
# Ausgabe: Eingabestring mit entfernter Interpunktion
#############################################################

def strip_punctuation(text):
    # Nur Zeichen in String übernehmen, die nicht in punctuation enthalten sind
    Text = ''.join(c for c in text if c not in punctuation)

    # Ausgabe
    return Text


"###############################################################################################################"
# word_seperator
"###############################################################################################################"

###############################################################################
# Wort in Vokale, Diphtonge und Konsonanten aufteilen
# Eingabe: Ein Wort als String
# Ausgabe: Liste mit in Wort enthaltenen, Vokalen, Diphtongen und Konsonanten
###############################################################################

def word_seperator(word):
    # Mit RE Vokale und Konsonanten finden und in Liste speichern
    syllables = re.findall(r""+vokale+"|"+konsonanten, word.lower())

    # Ausgabe der Liste
    return syllables                         


"###############################################################################################################"
# get_syllables
"###############################################################################################################"

########################################################
# Anzahl der Silben eines Wortes
# Eingabe: Wort als String
# Ausgabe: Anzahl der Silben des Wortes als Integer
########################################################

def get_syllables(word):
    # Wenn Wort ein Akronym ist
    if word == word.upper():
        # Länge des Wortes wiedergeben (In der Annahme, das jeder Buchstabe als eine Silbe ausgesprochen wird)
        return len(strip_punctuation(word))
    else:       
        # word lowercasen
        word = word.lower()
        # Mit regulärem Ausdruck Vokale finden
        vowels = re.findall(r"aa|oo|(?<![gb])ee|ae|ue|oe|ei|au|eu|äu|oy|ie|io|ua|ey|ai|ay|y(?![aeiouäöü])|a|e|i|o|u|ä|ö|ü", word)
        # Disambiguierung des Präix "-be" für Wörter mit Stamm "Beere" und "Beet"
        if word in re.findall(r"\w*[Bb]ee[rt]\w*", word):
            vowels = re.findall(r"aa|oo|ee|ae|ue|oe|ei|au|eu|äu|oy|ie|io|ua|ey|ai|ay|y(?![aeiouäöü])|a|e|i|o|u|ä|ö|ü", word)
        # Disambiguierung von "oo" für Wörter mit Stamm "Kooperation" und "Koordination"
        if word in re.findall(r"[Kk]ooperati\w+|[Kk]oordinati\w+", word):
            vowels = re.findall(r"aa|(?<![gb])ee|ae|ue|oe|ei|au|eu|äu|oy|ie|io|ua|ey|ai|ay|y(?![aeiouäöü])|a|e|i|o|u|ä|ö|ü", word)

        # Vokale zählen
        count = len(vowels)

        # Ausgabe
        return count


"###############################################################################################################"
# affix_seperator
"###############################################################################################################"

####################################################################################
# Wort in Affixe und Stamm aufteilen
# Eingabe: Wort als String
# Ausgabe: Liste mit seperiertem Wort in der Form: [Wort, Präfix, Stamm, Suffix]
####################################################################################

def affix_seperator(word):
    # Präfix als String mit RE finden
    präfix = "".join(re.findall(r"^("+präfixe+")(?:\w+)$",word.lower()))
    # Suffix als String mit RE finden
    suffix = "".join(re.findall(r"(?:^\w+)("+suffixe+")$", word.lower()))
    # Wenn kein Suffix vorhanden ggf. "-en" finden
    if suffix == "": 
        suffix = "".join(re.findall(r"(?:^\w+)(en)$",word.lower()))
    # Falls vorhanden Präfix bzw. Suffix von Stamm wegschneiden und als String speichern
    stamm = word
    if suffix != []: 
        stamm = stamm[:len(stamm)-len(suffix)]
    if präfix != []: 
        stamm = stamm[len(präfix):]

    # Ausgabe
    return [word, präfix, stamm, suffix]


"###############################################################################################################"
# get_gender
"###############################################################################################################"

###################################
# Genus eines Nomens bestimmen
# Eingabe: Wort als String
# Ausgabe: MASC/NEUT/FEM
###################################

def get_gender(word):
    word = strip_punctuation(word)
    # Suffixe zur Genusbestimmung
    neut_suffixes = "chen|lein|ment|ind|nis|(?<!l)ing|ma|um|en|o"
    masc_suffixes = "ismus|ling|ant|ich|(?<!m)ent|oge|ist|ich|or|er|at|us|ig"
    fem_suffixes = "schaft|heit|keit|ung|ion|[ae]nz|ik|(?<!e)in|ei|(?<!og)e|(?<!m)a|(?<!([ea]n|is|\wa))t"
    # Mit regulärem Ausdruck Listen erstellen, die ein Wort enthalten, falls gefunden
    neut = re.findall(r"^\w+("+neut_suffixes+")$", word)
    masc = re.findall(r"^\w+("+masc_suffixes+")$", word)
    fem = re.findall(r"^\w+("+fem_suffixes+")$", word)

    # leeren String <<gender>> definieren
    gender = ""

    # Prüfe ob Listen leer sind, wenn nicht weise entsprechendes Genus zu
    if neut != []:
        gender += "NEUT"
    if fem != []:
        gender += "FEM"
    if masc != []:
        gender += "MASC"
    # Wenn mehr als ein Genus erkannt wurde
    if gender == "" or len(gender) >= 5:
        # Default "MASC"
        gender = "MASC"

    # Prüfen ob Wort in einer Wortliste vorhanden ist
    if word.capitalize() in neut_words or word.replace("ä","ae").replace("ü","ue").replace("ö","oe").replace("ß","ss").capitalize() in neut_words:
        gender = "NEUT"
    if word.capitalize() in fem_words or word.replace("ä","ae").replace("ü","ue").replace("ö","oe").replace("ß","ss").capitalize() in fem_words:
        gender = "FEM"
    if word.capitalize() in masc_words or word.replace("ä","ae").replace("ü","ue").replace("ö","oe").replace("ß","ss").capitalize() in masc_words:
        gender = "MASC"

    # Wenn Wort kein bekanntes Suffix hat
    if word not in masc_words and word not in fem_words and word not in neut_words and affix_seperator(word)[3] == "":
        # Prüfe ob Wort in einer Wortliste vorhanden ist als letztes Glied einer Komposition
        # maskulin
        for tok in masc_words:
            if word.lower() == tok[-len(word):]:
                gender = "MASC"
        # feminin
        for tok in neut_words:
            if word.lower() == tok[-len(word):]:
                gender = "NEUT"
        # neutrum
        for tok in fem_words:
            if word.lower() == tok[-len(word):]:
                gender = "FEM"
    
    # Wenn Wort ein einziger groß geschriebener Buchstabe ist
    # genus aus NEUT setzen
    if len(word) == 1 and word in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']:
        gender = "NEUT"
    
    # Ausgabe
    return gender


"###############################################################################################################"
# get_det
"###############################################################################################################"

###########################################################################################################
# Diese Funktion gibt bestimmte und unbestimmte Artikel eines gegebenen Wortes wieder
# Eingabe: Wort
# Ausgabe: Tupel mit zwei Listen, 1. bestimmte, 2. unbestimmte Artikel, geordnet wie [nom, akk, dat, gen]
###########################################################################################################

def get_det(word):
    # Genus bestimmen
    gender = get_gender(word) 
    # Listen erstellen
    # maskulin
    if gender == "MASC":
        det = ["der", "den", "dem", "des"]
        indet = ["ein", "einen", "einem", "eines"]
        poss = "sein"
    # feminin
    elif gender == "FEM":
        det = ["die", "die", "der", "der"]
        indet = ["eine", "eine", "einer", "einer"]
        poss = "ihr"
    # neutral
    else:
        det = ["das", "das", "dem", "des"]
        indet = ["ein", "ein", "einem", "eines"]
        poss = "sein"
    # Ausgabe  
    return det, indet, poss


"###############################################################################################################"
# get_rhyme
"###############################################################################################################"

############################################################
# Reim und Akzentuierung erkennen
# Eingabe: Wort als String
# Ausgabe: Reimendung
# 1 ist Betont
# 0 ist Unbetont
############################################################

def get_rhyme(word):
    # Silbenanzahl
    syllables = get_syllables(word)
    # Liste mit eizelnen Morphemen des Wortes
    affixes = affix_seperator(word)
    # Liste mit orthographisch relevanten Einheiten des Wortes erstellen
    word_sep = word_seperator(word)
  
    # Betont: | unbetont: -
    metrum = ""
  
    # Sollte keine Silbe gefunden werden
    if syllables == 0:
        word_sep = ""
    
    # Wenn Wort einsilbig ist
    if syllables == 1:
        # Konsonanten bis zum Reim entfernen
        while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
            word_sep.pop(0)
        metrum = "-"
      
    # Wenn Wort zweisilbig ist
    if syllables == 2:
        # bei unbetontem Präfix und keinem unbetontem Suffix
        if affixes[1] in präfixe_unbetont.split("|") and affixes[3] not in suffixe_unbetont.split("|"):
            # Reim auf zweiter Silbe
            # erste Silbe entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            word_sep.pop(0)
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "01"
        # Bei Betontem Suffix
        elif affixes[3] in suffixe_betont.split("|"):
            # Reim auf zweiter Silbe
            # erste Silbe entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            word_sep.pop(0)
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "01"
        # bei unbetontem Suffix
        elif affixes[3] in suffixe_unbetont.split("|"):
            # Reim auf erster Silbe
            # Konsonanten bis zum ersten Vokal entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "10"
        # Default: erste Silbe trägt Reim
        else:
            # Konsonanten bis zum ersten Vokal entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "10"
  
    # Wenn Wort dreisilbig ist
    elif syllables == 3:
        # bei unbetontem Präfix
        if affixes[1] in präfixe_unbetont.split("|"):
            # Reim auf zweiter Silbe
            # erste Silbe entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            word_sep.pop(0)
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "010"
        # bei betontem Präfix
        elif affixes[1] in präfixe_betont.split("|"):
            # Reim auf erster Silbe
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "101"
        # bei unbetontem Präfix
        elif affixes[3] in suffixe_unbetont.split("|"):
            # Reim auf erster Silbe
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "101"
        # bei betontem Suffix
        elif affixes[3] in suffixe_betont.split("|"):
            # wenn Suffix == -ieren
            # Reim auf zweiter Silbe
            if affixes[3] == "ieren":
                # erste Silbe entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                word_sep.pop(0)
                # Konsonanten bis zum Reim entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                metrum = "010"
            # Default: Reim auf letzter Silbe
            else:
                # erste Silbe entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                word_sep.pop(0)
                # Konsonanten bis zum Reim entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                # zweite Silbe entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                word_sep.pop(0)
                # Konsonanten bis zum Reim entfernen
                while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                    word_sep.pop(0)
                metrum = "101"
        # Default:Reim auf zweiter Silbe
        else:
            # erste Silbe entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            word_sep.pop(0)
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            metrum = "010"
        
    # wenn Wort mehr als drei Silben hat
    elif syllables > 3:
        # bei betontem Suffix
        if affixes[3] in suffixe_betont.split("|") and affixes[1] not in präfixe_betont.split("|"):
            # Reim ist das Suffix
            word_sep = list(affixes[3])
            # Wenn Suffix -ieren ist
            if affixes[3] == "ieren":
                # Verkehrt herum Metrum befüllen
                metrum = "01"
                # Für jede weitere Silbe nach Suffix
                for step in range(syllables-2):
                    if metrum[-1] == "1":
                        metrum += "0"
                    else:
                        metrum += "1"
                # Metrum umdrehen
                metrum = metrum[::-1]
            # Bei anderem Suffix
            else:
                # Verkehrt herum Metrum befüllen
                metrum = "1"
                # Für jede weitere Silbe nach Suffix
                for step in range(syllables-1):
                    if metrum[-1] == "1":
                        metrum += "0"
                    else:
                        metrum += "1"
                # Metrum umdrehen
                metrum = metrum[::-1]
        # Bei betontem Präfix
        elif affixes[1] in präfixe_betont.split("|"):
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            # Metrum
            metrum = "1"
            for step in range(syllables-1):
                if metrum[-1] == "1":
                    metrum += "0"
            else:
                metrum += "1"
        # Bei unbetontem Präfix
        elif affixes[1] in präfixe_unbetont.split("|"):
            # Reim auf zweiter Silbe
            # erste Silbe entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            word_sep.pop(0)
            # Konsonanten bis zum Reim entfernen
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                 word_sep.pop(0)
            # Metrum
            metrum = "0"
            for step in range(syllables-1):
                if metrum[-1] == "1":
                    metrum += "0"
                else:
                    metrum += "1"
        # Default: erste Silbe trägt Reim
        else:
            while len(word_sep) != 0 and word_sep[0] not in vokale_liste:
                word_sep.pop(0)
            # Metrum
            metrum = "1"
            for step in range(syllables-1):
                if metrum[-1] == "1":
                    metrum += "0"
                else:
                    metrum += "1"
             
    # word_sep in rhyme umbenennen
    rhyme = "".join(word_sep)
        
    # Bei einem Akronym ist die Reimendung dem letzten Buchstaben entsprechend
    # Wenn alle Buchstaben groß geschrieben sind
    if word.upper() == word and len(word) != 0:
        # Wenn letzter Buchstabe A,H, oder K ist
        if word[-1] in ["A","H","K"]:
            # setzte "a" als Reimendung fest
            rhyme = "a"
        # Für jeden Buchstaben weitermachen...
        if word[-1] in["B","C","D","E","G","P","T","W"]:
            rhyme = "ee"
        if word[-1] == "F":
            rhyme = "eff"
        if word[-1] == "I":
            rhyme = "ie"
        if word[-1] == "J":
            rhyme = "ott"
        if word[-1] == "L":
            rhyme = "ell"
        if word[-1] == "M":
            rhyme = "emm"
        if word[-1] == "N":
            rhyme = "enn"
        if word[-1] == "O":
            rhyme = "oh"
        if word[-1] == "Q":
            rhyme = "uh"
        if word[-1] == "R":
            rhyme = "er"
        if word[-1] == "S":
            rhyme = "ess"
        if word[-1] == "U":
            rhyme = "uh"
        if word[-1] == "V":
            rhyme = "au"
        if word[-1] == "X":
            rhyme = "ix"
        if word[-1] == "Y":
            rhyme = "onn"
        if word[-1] == "Z":
            rhyme = "ett"
        # Metrum neu definieren
        metrum = ""
        # Über jeden Buchstaben in word iterieren
        for letter in word:
            # Jeder zweite Buchstabe ist unbetont (101010...)
            if word.index(letter) % 2 == 0:
                metrum += "1"
            else:
                metrum += "0"
    
    # Reim als einziges Element in einer Liste speichern
    rhyme = rhyme.split()
    # Wenn Reimendung leer ist füge ein leeres Element in die Liste hinzu
    if rhyme == []:
        rhyme = [""]

    # Wenn Reimendung länger als 1 ist
    if len(rhyme[0]) > 1:
        # Homophonie
        # Konsonantenverhärtung am Ende des Wortes
        # Wenn ein stimmhafter Vokal am Ende des Wortes ist und nicht verdoppelt vorkommt
        if rhyme[0][-1] in kons_stimmhaft and rhyme[0][-2] != rhyme[0][-1] and rhyme[0][-2:] != "ng":
            # Füge Reim die Variante mit stimmlosem Konsonant hinzu
            rhyme.append(rhyme[0][:-1]+kons_stimmlos[kons_stimmhaft.index(rhyme[0][-1])])
        # Orthographische Variationen bei Konsonanten
        # über jeden Buchstaben im Reim iterieren
        for letter in rhyme[0]:
            # wenn Buchstabe in Reim nur einmal und nicht verdoppelt vorkommt
            if letter in kons_normal and letter+letter not in rhyme[0]:
                # wenn Buchstabe nicht x ist
                if letter != "x":
                    # Füge Reim entsprechende Varianten aus kons_alternativ hinzu
                    rhyme.append(re.sub(letter,kons_alternativ[kons_normal.index(letter)],rhyme[0]))
                # Wenn Buchstabe x ist
                else:
                    # Füge Reim jede x-Variante aus kons_alternativ hinzu
                    for x in kons_alternativ[kons_normal.index(letter)]:
                        rhyme.append(re.sub(letter,x,rhyme[0]))
        # Homophonie bei Vokalen und Diphtongen
        for vowel in vok_diph_normal:
            # wenn Vokal in reim
            if vowel in rhyme[0]:
                # Reimvarianten mit substitution finden
                vowel_change = re.sub(vowel,vok_diph_alternativ[vok_diph_normal.index(vowel)],rhyme[0])
                # wenn Substitution nicht dieselbe wie Reim ist
                if vowel_change != rhyme[0]:
                    # füge diese der Reimliste hinzu
                    rhyme.append(vowel_change)
        # Doppelvokal und Vokal-h  (langer Vokal)
        if re.findall("e{2}|a{2}|o{2}[^lmnkd]",rhyme[0]) != [] and re.findall("eee|aaa|iii|uuu|ooo",rhyme[0]) == []:
            rhyme.append(rhyme[0].replace("aa","ah").replace("uu","uh").replace("oo","oh"))
    
    # Ausgabe
    return rhyme


"###############################################################################################################"
# match_rhymes
"###############################################################################################################"

############################################################
# Prüft, ob Reime zweier Wörter identisch sind
# Eingabe: Zwei Wörter als String
# Ausgabe: "YES" bzw. "NO"
############################################################
def match_rhymes(word1, word2):
    # Liste mit Reimen des ersten Wortes
    rhymes1 = get_rhyme(word1)
    # Liste mit Reimen des zweiten Wortes
    rhymes2 = get_rhyme(word2)
    
    # match auf "NO" setzen
    match = "NO"
    
    # Wenn keines der Wörter Teil des anderen Wortes ist und keines der Wörter hoch ist (hoch hat keinen Reim)
    if word1.lower() not in word2.lower() and word2.lower() not in word1.lower() and word1.lower() != "hoch" and word2.lower() != "hoch" and word1.lower().replace("ue","ü").replace("ae","ä").replace("oe","ö") != word2.lower().replace("ue","ü").replace("ae","ä").replace("oe","ö"):
        # über Liste mit Reimvarianten iterieren
        for rhyme in rhymes1:
            # Wenn beide Wörter eine gemeinsame Reimvariante haben
            if rhyme in rhymes2:
                # setzte match auf "YES"
                match = "YES"
               
    # Ausgabe
    return match