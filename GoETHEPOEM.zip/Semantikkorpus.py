# -*- coding: utf-8 -*-

# Aus Modul 'Orthographie' importeren
from Orthographie import strip_punctuation, punctuation, plural_words, sg_nouns, get_rhyme, match_rhymes
# Counter
from collections import Counter
# choice
from random import choice
# re
import re

"###########################################################################################################"
# noun associations
"###########################################################################################################"

#####################################################################################################
# Auf der Website http://www.psycholing.es.uni-tuebingen.de/nag/index.php? wird die Möglichkeit
# geboten sich eine csv-Datei mit noun associations nach eigenen Parametern zu erstellen.
# Die Parameter der hier vewendeten Datei, also die Spalten sind:
# 0 Stimulus, 1 POS-Tag, 2 relation type, 3 Stimulus, 4 category
# Im Folgenden wird mit Hilfe dieser Tabelle eine neue txt-Datei erstellt, in der die
# vorverarbeiteten Daten gespeichert werden. Hierzu wird zunächst eine Liste erstellt, dessen 
# Elemente (Zeilen) später in eine Datei geschrieben werden. Leere Einträge, sowie solche, die aus 
# Zahlen bestehen oder Interpunktion innehaben werden nicht berücksichtigt. Weiterhin werden die
# POS-Tags in NN, VVINF, ADJX umbenannt.
#####################################################################################################

##########################################
#   "Noun_Associations_For_German.csv"   #
##########################################
# Datei "Noun_Associations_For_German.csv" öffnen
na_open = open("Noun_Associations_For_German.csv", encoding = "UTF-8")
# Datei einlesen
na_read = na_open.read()
# Spalten splitten, Zeilen splitten
na_split = [row.split(";")[1:] for row in na_read.split("\n") if len(row.split(";")) == 6][1:]
# Nur relevante Einträge, mit response, ohne Ziffern, ohne Interpunktion
na_relevants = [row for row in na_split if row[0] != " - (keine Antwort) " and row[0] == re.sub("\d","", row[0]) and row[0] == re.sub(r"["+punctuation+"]", "", row[0])]
# unnötigen Whitespace entfernen
na_whitespace = [[row[0][1:-1]]+[re.sub("\s","",element) for element in row[1:]] for row in na_relevants if row[0][1:-1] != ""]
# Einträge, die mehr als ein Wort enthalten entfernen
single_words = [row for row in na_whitespace if len(row[0].split()) == 1]
# Tags umbenennen, nur getaggte Einheiten behalten. Außerdem 2. Element (Frequenz) in integer umwandeln
na_newtags = [[row[0], row[1].replace("Adjektiv","ADJX").replace("Nomen","NN").replace("Verb","VVINF"), row[2],row[3],row[4]] for row in single_words if row[1] in ["Nomen", "Verb", "Adjektiv"]]
# Dict erstellen mit Counter und vorkommen zählen
na_counter = Counter([tuple(entry) for entry in na_newtags])
# Wieder in Liste überführen und Vorkommen als letztes Element jeden Eintrags einfügen
na_counts = [list(entry)+[na_counter[entry]] for entry in na_counter]
# Nomen von Singular und Plural unterschieden, alle Pluralformen entfernen
# Liste umbenennen
na_alltags = na_counts
for entry in na_alltags:
    if entry[1] == "NN" and entry[0].replace("ä","ae").replace("ü","ue").replace("ö","oe").replace("ß","ss").capitalize() in plural_words and entry[0].replace("ä","ae").replace("ü","ue").replace("ö","oe").replace("ß","ss").capitalize() not in sg_nouns:
        na_alltags.remove(entry)

# Falsch getaggte Verben ohne "n"-Endung korrigieren
# anhand folgender erstellter Listen:
NN = ['Auto', 'Groesse', 'Hand', 'Lastzug', 'Papier', 'Reiterhof']
NNPL = ['Fahrgaeste']
ADJX = ['anstrengend', 'biegsam', 'dekorativ', 'elegant', 'erf', 'gesund', 'glaenzend', 'glatt', 'grau',
        'hart', 'herzlich', 'historisch', 'kalt', 'krank', 'kruemelig', 'laestig', 'lustig', 'schick', 'schnell', 
        'sprudelnd', 'zittrig']
VV3SG = ['riecht', 'schmeckt']
# Jeden Fehler korrigieren und entsprechenden Tag ersetzen
for entry in na_alltags:
    if entry[1] == "VVINF" and entry[0][-1] != "n":
        if entry[0] in NN:
            na_alltags[na_alltags.index(entry)][1] = "NN"
        if entry[0] in NNPL:
            na_alltags[na_alltags.index(entry)][0] = "Fahrgast"
            na_alltags[na_alltags.index(entry)][1] = "NN"
        if entry[0] in ADJX:
            na_alltags[na_alltags.index(entry)][1] = "ADJX"
        if entry[0] in VV3SG:
            na_alltags[na_alltags.index(entry)][0] = na_alltags[na_alltags.index(entry)][0][:-1]+"en"
    # zusätzlich: Erbsen und Trauben (Stimuli im Plural) in Singular umwandeln
    if entry[3] in ["Erbsen","Trauben"]:
        na_alltags[na_alltags.index(entry)][3] = na_alltags[na_alltags.index(entry)][3][:-1]
    # zusätzlich: Waffen (Kategorie im Plural) in Singular umwandeln
    if entry[4] == "Waffen":
        na_alltags[na_alltags.index(entry)][4] = na_alltags[na_alltags.index(entry)][4][:-1]
                  
# Datei schließen
na_open.close()

###################
#   ß-Korrektur   #
###################
# Wörter, die mit ß geschrieben werden finden und ersetzen (Wichtig für die Reimerkennung)
# Datei "ss_words.txt" öffnen
ss_open = open("ss_words.txt", encoding = "UTF-8")
# Datei einlesen
ss_read = ss_open.read()
# Liste mit Wörtern erstellen
ss_words = [word for word in ss_read.split("\n") if word != ""]
# Über na_alltags iterieren
for entry in na_alltags:
    # responses berichtigen
    if "ss" in entry[0] and entry[0].replace("ss","ß") in ss_words:
        na_alltags[na_alltags.index(entry)][0] = entry[0].replace("ss","ß")
    # stimuli berichtigen
    if "ss" in entry[3] and entry[3].replace("ss","ß") in ss_words:
        na_alltags[na_alltags.index(entry)][3] = entry[3].replace("ss","ß")
    # Verben mit eindeutigen Endungen berichtigen
    if "ss" in entry[0] and entry[1] == "VVINF" and len(entry[0]) >= 6 and entry[0][-6:] in ["iessen", "eissen", "stossen"]:
        na_alltags[na_alltags.index(entry)][0] = entry[0].replace("ss","ß")
# Datei schließen
ss_open.close()

####################################
#   "Associations.txt" erstellen   #
####################################
# Datei "Associations.txt" erstellen
# Jeder Eintrag (Zeile) ist von einem Zeilenumbruch getrennt.
# Jedes Element einer Zeile ist von einem Tabulator getrennt
file = open("Associations.txt","w", encoding = "UTF-8")
for row in na_alltags:
    for entry in row:
        file.write(str(entry)+"\t")
    file.write("\n")
file.close()


"################################"
# openthesaurus.txt
"################################"

########################################################################
# Auf https://www.openthesaurus.de/ wird ein Semantisches Lexikon mit
# Einträgen zu Synonymen und Assoziationen von Wörtern bereitgestellt.
# Die hier verwendete Datei ist eine txt-Datei und enthält Worteinträge
# mit ihren Synonymen von ";" getrennt.
########################################################################

# ot_dict erstellen, zum zugreifen auf Lexikoneinträge
# Datei öffnen
ot_open = open("openthesaurus.txt", encoding = "UTF-8")
# Datei einlesen
ot_read = ot_open.read().replace("ü","ue").replace("ä","ae").replace("ö","oe").replace("Ü","Ue").replace("Ä","Ae").replace("Ö","Oe")
# Liste mit Einträgen erstellen (Ohne Vorwort und letztes (leeres) Element)
ot_split = [entry.split(";") for entry in ot_read.split("\n")[18:-1]]
# # ot_dict erstellen
ot_dict = {}
# über Liste mit Einträgen iterieren
for entry in ot_split:
    # über Wörter in Eintrag iterieren
    for word in entry:
        # Eintrag erstellen und Wörter einfügen, wenn keine Leerzeichen und keine Interpunktion vorhanden ist
        if word not in ot_dict and len(word.split()) == 1 and strip_punctuation(word) == word:
            ot_dict[word] = [tok for tok in entry if tok != word and len(tok.split()) == 1 and strip_punctuation(tok) == tok]
        # Gegebenen Falls Eintrag um Wörter erweitern, die noch nicht enthalten sind
        elif word in ot_dict and len(word.split()) == 1 and strip_punctuation(word) == word:
            ot_dict[word] += [tok for tok in entry if tok != word  and len(tok.split()) == 1 and tok not in ot_dict[word] and strip_punctuation(tok) == tok]
# Datei schließen
ot_open.close()


####################
#  rhymeends_dict  #
####################
# Erstellung eines Dicts mit Reimendungen und den dazugehörigen Wörtern mit POS-Tag
# Keys: Reimendungen
# Values: Tupeln mit Wort und POS-Tag in einer Liste
rhymeends_dict = {}
# über Liste mit Wort-Tag-Tupeln iterieren (So, dass jedes Wort des Korpus vorkommt)
for word in list(set([(entry[0],entry[1]) for entry in na_alltags])):
    # über jede gefundene Reimvariante des Wortes iterieren
    for rhyme in get_rhyme(word[0]):
        # Alle Reimendungen in rhymeends_dict speichern
        # und alle Wörter mit derselben Endung als Value in einer Liste hinzufügen
        if rhyme not in rhymeends_dict:
            rhymeends_dict[rhyme] = [(word[0],word[1])]
        else:
            rhymeends_dict[rhyme] += [(word[0],word[1])]

# Einträge mit nur einem Vorkommen entfernen
for entry in list(rhymeends_dict.items()):
    if len(entry[1]) < 2:
        del rhymeends_dict[entry[0]]
        
        
# (Diese folgende Funktion wird in einem späteren Modul "generator" nocheinmal aufgegriffen und neu definiert)
"#############################################################################################################"
# read_associations
"#############################################################################################################"

##############################################################################################
# Funktion zum Einlesen einer Vorverarbeiteten noun associations-Datei und zum Erstellen
# entsprechender dictionaries, zum effizienteren Suchen nach Einträgen.
# Eingabe: txt-Datei
# Ausgabe: Tupel mit dicts: (posdict, responsedict, stimulusdict, categorydict)
##############################################################################################
def read_associations(file):
    # Datei öffnen
    associations_open = open(file, encoding = "UTF-8")
    # Datei einlesen
    associations_read = associations_open.read()
    # Liste erstellen mit Zeileneinträgen
    associations_list = [i.split("\t")[:-1] for i in associations_read.split("\n") if i != ""]
    # Datei schließen
    associations_open.close()
    
    # Dictionaries erstellen, von denen man direkt auf passende Einträge zugreifen kann
    # Für jede Spalte (außer relation type) wir ein Dict erstellt
    # posdict
    posdict = {}
    for row in associations_list:
        if row[1] not in posdict:
            posdict[row[1]] = [row]
        else:
            posdict[row[1]] += [row]
    # responsedict
    responsedict = {}
    for row in associations_list:
        if row[0] not in responsedict:
            responsedict[row[0]] = [row]
        elif row[0] in responsedict:
            responsedict[row[0]] += [row]
    # stimulusdict
    stimulusdict = {}
    for row in associations_list:
        if row[3] not in stimulusdict:
            stimulusdict[row[3]] = [row]
        if row[3] in stimulusdict and row not in stimulusdict[row[3]]:
            stimulusdict[row[3]] += [row]
    # categorydict
    categorydict = {}
    for row in associations_list:
        if row[4] not in categorydict:
            categorydict[row[4]] = [row]
        else:
            categorydict[row[4]] += [row]
        
    # Ausgabe
    return posdict, responsedict, stimulusdict, categorydict


"###############################################################################################################"
# write_relationmodell
"###############################################################################################################"

#############################################################################################################
# Funktion, die für jede Response zusammenhängende Wörter erkennt, in ein dict schreibt und anschließend
# die Ergebnisse in einer Datei "relationmodell.txt" speichert. Reliert Wörter werden hierbei definiert als: 
# 1. Jeder Stimulus, der in den verschiedenen Einträgen derselben Response vorkommt. 
# 2. Jede Kategorie, die den Responses aus 1. zugeteilt ist.
# 3. Jede Response, dessen Stimulus und Kategorie mit den bereits erkannten Simuli und Kategorien 
#    übereinstimmen, wobei alle Kombinationen möglich sind.
# Eingabe: responsedict, stimulusdict
# Ausgabe: relationdict (Außerdem wird eine txt-Datei geschrieben)
#############################################################################################################
def write_relationmodell(responsedict, stimulusdict):
    relationdict = {}
    # stimuli
    # Iteriere über stimulusdict
    for stimulus in stimulusdict:
        # wenn stimulus nicht in relationdict
        if stimulus not in relationdict:
            # Eintrag erstellen
            relationdict[stimulus] = []
            # Responses der Stimuli und Kategorie hinzufügen (30)
            for entry in stimulusdict[stimulus]:
                # Response hinzufügen
                if (entry[0],entry[1],30) not in relationdict[stimulus]:
                    relationdict[stimulus] += [(entry[0],entry[1],30)]
                # Kategorie hinzufügen
                if (entry[4],"NN",30) not in relationdict[stimulus]:
                    relationdict[stimulus] += [(entry[4],"NN",30)]
        # Wörter derselben Kategorie
        category = choice([entry[4] for entry in stimulusdict[stimulus]])
        for entry in categorydict[category]:
            # Stimulus derselben Kategorie hinzufügen (20)
            if (entry[4],"NN",20) not in relationdict[stimulus] and (entry[4],"NN",30) not in relationdict[stimulus]:
                relationdict[stimulus] += [(entry[4],"NN",20)]
            # Responses der Stimuli derselben Kategorie hinzufügen (10)
            if (entry[0],entry[1],10) not in relationdict[stimulus] and (entry[0],entry[1],20) not in relationdict[stimulus] and (entry[0],entry[1],30) not in relationdict[stimulus] and int(entry[-1]) > 1:
                relationdict[stimulus] += [(entry[0],entry[1],10)]
        # Wenn Stimulus auch in responsedict vorhanden ist
        if stimulus in responsedict:
            for entry in responsedict[stimulus]:
                # Responses des Stimulus hinzufügen (20)
                if (entry[3],"NN",10) not in relationdict[stimulus] and (entry[3],"NN",20) not in relationdict[stimulus] and (entry[3],"NN",30) not in relationdict[stimulus]:
                    relationdict[stimulus] += [(entry[3],"NN",20)]

    # responses
    # über responsedict iterieren
    for response in responsedict:
        # wenn response nicht in relationdict
        if response not in relationdict:
            relationdict[response] = []
            stimuli = []
            categories = []
            # stimuli und Kategorien in Listen speichern
            for response_entry in responsedict[response]:
                # stimuli einfügen
                if response_entry[3] not in stimuli:
                    stimuli.append(response_entry[3])
                # kategorien einfügen
                if response_entry[4] not in categories:
                    categories.append(response_entry[4])
            # Stimuli in dicteintrag speichern (30)
            relationdict[response] += [(stimulus,"NN",30) for stimulus in stimuli]
            # Kategorie in dicteintrag speichern (30)
            relationdict[response] += [(category,"NN",30) for category in categories]
            # Alle relierten reponses, der bereits gespeicherten Stimuli und Kategorien in Liste eintragen
            for stimulus in stimuli:
                related_to_response = []
                # über jeden Eintrag itereieren, der dem Stimulus zugrundeliegt
                for stimulus_entry in stimulusdict[stimulus]:
                    # Wenn Eintrag noch nicht in related_to_response und nicht in relationdict
                    # und wenn Stimulus in der Liste mit relierten Stimuli ist
                    # und wenn die Response mindestens 5 mal vorhanden war
                    if (stimulus_entry[0],stimulus_entry[1],20) not in related_to_response and stimulus_entry[0] not in [word[0] for word in relationdict[response]] and stimulus_entry[3] in stimuli and int(stimulus_entry[-1]) >= 5:
                        # Füge Wort und Tag related_to_response hinzu (20)
                        related_to_response.append((stimulus_entry[0],stimulus_entry[1],20))
                    # Wenn Eintrag noch nicht in related_to_response und nicht in relationdict
                    # und wenn Stimulus in der Liste mit relierten Stimuli ist
                    # und wenn die Response mindestens 2 mal vorhanden war
                    if (stimulus_entry[0],stimulus_entry[1],10) not in related_to_response and (stimulus_entry[0],stimulus_entry[1],20) not in related_to_response and stimulus_entry[0] not in [word[0] for word in relationdict[response]] and stimulus_entry[3] in stimuli and int(stimulus_entry[-1]) > 1 and int(stimulus_entry[-1]) < 5:
                        # Füge Wort und Tag related_to_response hinzu (10)
                        related_to_response.append((stimulus_entry[0],stimulus_entry[1],10))
                relationdict[response] += related_to_response
                
    # Wörter aus openthesaurus hinzufügen
    # über Relationdict iterieren
    for word in relationdict:
        ## Synonyme für das direkte Wort finden
        # Wort mit Umlauten speichern (oe -> ö usw.)
        umlaut_word = word.replace("ue","ü").replace("ae","ä").replace("oe","ö")
        # Wenn Wort in ot_dict enthalten
        if word in ot_dict:
            # iteriere über den Eintrag in ot_dict
            for tok in ot_dict[word]:
                # POS bestimmen
                # Wenn Wort in responsedict
                if word in responsedict:
                    # Entsprechenden POS-Tag speichern
                    pos = responsedict[word][0][1]
                # Andernfalls
                else:
                    # NN als Tag festlegen
                    pos = "NN"
                # Eintrag in Relationdict um tok erweitern (40 Punkte zuweisen)
                relationdict[word] += [(tok, pos, 40)]
        # Wenn Wort mit Umlauten in ot_dict enthalten und Wort nicht schon verwendet
        if umlaut_word in ot_dict and word not in ot_dict:
            # iteriere über den Eintrag in ot_dict
            for tok in ot_dict[umlaut_word]:
                # POS bestimmen
                # Wenn Wort in responsedict
                if word in responsedict:
                    # Entsprechenden POS-Tag speichern
                    pos = responsedict[word][0][1]
                # Andernfalls
                else:
                    # NN als Tag festlegen
                    pos = "NN"
                # Eintrag in Relationdict um tok erweitern (40 Punkte zuweisen)
                relationdict[word] += [(tok, pos, 40)]

        ## Synonyme für bereits im Eintrag vorhandene Wörter finden
        # Liste new_words erstellen
        new_words = []
        # Wenn 100 oder weniger Wörter eingetragen sind
        if len(relationdict[word]) <= 100:
            # Über relierte Wörter im relationdicteintrag iterieren
            for related_word in relationdict[word]:
                # # Wort mit Umlauten speichern (oe -> ö usw.)
                umlaut_related_word = (related_word[0].replace("ue","ü").replace("ae","ä").replace("oe","ö"), related_word[1], related_word[2])
                # Wenn der Level 10, 20 oder 30 ist
                if related_word[2] in [10, 20,30]:
                    # Wenn Wort in ot_dict
                    if related_word[0] in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, related_word[1], related_word[2]) not in new_words:
                                new_words.append((tok, related_word[1], related_word[2]))
                    # Wenn Wort mit Umlauten in ot_dict enthalten und Wort nicht schon verwendet
                    if umlaut_related_word[0] in ot_dict and related_word[0] not in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[umlaut_related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, umlaut_related_word[1], umlaut_related_word[2]) not in new_words:
                                new_words.append((tok, umlaut_related_word[1], umlaut_related_word[2]))

        # Wenn 101-200 Wörter eingetragen sind
        if len(relationdict[word]) > 150 and len(relationdict[word]) <= 200:
            # Über relierte Wörter im relationdicteintrag iterieren
            for related_word in relationdict[word]:
                # # Wort mit Umlauten speichern (oe -> ö usw.)
                umlaut_related_word = (related_word[0].replace("ue","ü").replace("ae","ä").replace("oe","ö"), related_word[1], related_word[2])
                # Wenn der Level 20 oder 30 ist
                if related_word[2] in [20,30]:
                    # Wenn Wort in ot_dict
                    if related_word[0] in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, related_word[1], related_word[2]) not in new_words:
                                new_words.append((tok, related_word[1], related_word[2]))
                    # Wenn Wort mit Umlauten in ot_dict enthalten und Wort nicht schon verwendet
                    if umlaut_related_word[0] in ot_dict and related_word[0] not in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[umlaut_related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, umlaut_related_word[1], umlaut_related_word[2]) not in new_words:
                                new_words.append((tok, umlaut_related_word[1], umlaut_related_word[2]))

        # Wenn mehr als 200 Wörter eingetragen sind          
        if len(relationdict[word]) > 200:
            # Über relierte Wörter in relationdict iterieren
            for related_word in relationdict[word]:
                # Wort mit Umlauten speichern (oe -> ö usw.)
                umlaut_related_word = (related_word[0].replace("ue","ü").replace("ae","ä").replace("oe","ö"), related_word[1], related_word[2])
                # Wenn der Level 30 ist
                if related_word[2] == 30:
                    # Wenn Wort in ot_dict
                    if related_word[0] in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, related_word[1], related_word[2]) not in new_words:
                                new_words.append((tok, related_word[1], related_word[2]))
                    # Wenn Wort mit Umlauten in ot_dict enthalten und Wort nicht schon verwendet
                    if umlaut_related_word[0] in ot_dict and related_word[0] not in ot_dict:
                        # über Wörter in Eintrag in ot_dict iterieren
                        for tok in ot_dict[umlaut_related_word[0]]:
                            # Wort in new_words einfügen
                            if (tok, umlaut_related_word[1], umlaut_related_word[2]) not in new_words:
                                new_words.append((tok, umlaut_related_word[1], umlaut_related_word[2]))
        relationdict[word] += new_words
        # Alle identischen Einträge entfernen
        relationdict[word] = list(set(relationdict[word]))
                
    # Datei öffnen
    relationmodell = open("relationmodell.txt","w",encoding="UTF-8")
    # iteriere über relationdict
    for word in relationdict:
        # schreibe Wort und |
        relationmodell.write(word+"|")
        # iteriere über dicteintrag, also Liste mit jedem Wort, mit POS-Tag in Tupel
        for wordpos in relationdict[word]:
            # Schreibe Paar1 und Paar2 von Leerzeichen getrennt und jedes Paar voneinander von Tabulator getrennt
            relationmodell.write(wordpos[0]+" "+wordpos[1]+" "+str(wordpos[2])+"\t")
        # Zeilenumbruch kennzeichnet den nächsten Eintrag
        relationmodell.write("\n")
    # Datei schließen
    relationmodell.close

    # relationdict ausgeben
    return relationdict


"###############################################################################################################"
# write_rhymemodell
"###############################################################################################################"

# Funktion zur Erstellung eines Reimmodells. Zunächst wird ein Reimdictionary erstellt, in welchem zu jedem
# Wort Relierte Reimpaare gespeichert sind, die wiederum in einem Dict verschachtelt sind und nach POS-Paaren
# Sortiert sind. Form: Wort : { (POS1,POS2) : { (wort1,wort2),... } ,... }
# Anschließend werden die Einträge des Dicts in eine Datei geschrieben, so dass sie jederzeit eingelesen
# und wieder in ein Reimdict umgewandelt werden kann.
def write_rhymemodell(relationdict):
    # leeres dict erstellen
    rhymedict = {}
    # counter auf 0 setzten
    counter = 0
    # Über jeden Eintrag in relationdict iterieren
    for word in relationdict:
        # counter 1 hinzufügen und Status ausgeben
        counter += 1
        print(word,counter,"of",len(relationdict))
        # Wenn Eintrag nicht in rhymedict
        if word not in rhymedict:
            # Eintrag erstellen
            rhymedict[word] = {}
        # über jede Wort-POS-Tupel in Liste aus relationdict iterieren
        for relword1 in relationdict[word]:
            # über jede Wort-POS-Tupel in Liste aus relationdict iterieren
            for relword2 in relationdict[word]:
                # Wenn POS-Paar-Tupel keinen Eintrag hat
                if (relword1[1],relword2[1]) not in rhymedict[word]:
                    # Eintrag erstellen, mit leerer Liste
                    rhymedict[word][(relword1[1],relword2[1])] = []
                if match_rhymes(relword1[0],relword2[0]) == "YES":
                    rhymedict[word][(relword1[1],relword2[1])].append((relword1[0],relword2[0],relword1[2]+relword2[2]))
                    
        # Anzahl der Reimpaare Zählen
        lenght = 0
        for pospair in rhymedict[word]:
            lenght += len(rhymedict[word][pospair])
        # Wenn weniger als 10 Reimpaare gefunden wurden
        # (Zusätzliche Reimpaare finden: Mithilfe des rhymeends_dict dieselben Reime der Wörter aus dem Korpus identifizieren
        # und mit einem relierten Wort ein neues Reimpaar schaffen und den Eintrag um diesen ergänzen)
        if lenght < 10:
            # über liste der relierten Wörter iterieren
            for related_word in relationdict[word]:
                # über jede Reimvariante des Wortes iterieren
                for rhyme in get_rhyme(related_word[0]):
                    # Wenn die Reimendung in rhymeends_dict vorhanden ist
                    if rhyme in rhymeends_dict:
                        # über die Liste mit Wörtern derselben Reimendung iterieren
                        for rhyme_word in rhymeends_dict[rhyme]:
                            # Wenn das relierte Wort und das Wort aus der Liste der Reimendungen sich reimen (Und sie nicht mit NNPL oder NAME getaggt sind)
                            if match_rhymes(related_word[0],rhyme_word[0]) == "YES":
                                # Eintrag für das Wort im rhymedict ergänzen
                                if (related_word[1],rhyme_word[1]) not in rhymedict[word]:
                                    rhymedict[word][(related_word[1],rhyme_word[1])] = [(related_word[0],rhyme_word[0],related_word[2]+5)]
                                else:
                                    if (related_word[0],rhyme_word[0]) not in rhymedict[word][(related_word[1],rhyme_word[1])]:
                                        rhymedict[word][(related_word[1],rhyme_word[1])] += [(related_word[0],rhyme_word[0],related_word[2]+5)]
                                # Eintrag für das Wort im rhymedict ergänzen (umgekehrte Reihenfolge)
                                if (rhyme_word[1],related_word[1]) not in rhymedict[word]:
                                    rhymedict[word][(rhyme_word[1],related_word[1])] = [(rhyme_word[0],related_word[0],related_word[2]+5)]
                                else:
                                    if (rhyme_word[0],related_word[0]) not in rhymedict[word][(rhyme_word[1],related_word[1])]:
                                        rhymedict[word][(rhyme_word[1],related_word[1])] += [(rhyme_word[0],related_word[0],related_word[2]+5)]

    # Datei öffnen
    rhymemodell = open("rhymemodell.txt","w",encoding="UTF-8")
    # iteriere über rhyme_dict
    for word in rhymedict:
        # wort|
        rhymemodell.write(word+"|")
        # über dict mit POS-Paaren iterieren
        for pospair in rhymedict[word]:
            # {pospair1\tpospair2[
            rhymemodell.write("{"+pospair[0]+"\t"+pospair[1]+"[")
            # über Liste mit Wortpaaren iterieren
            for wordpair in rhymedict[word][pospair]:
                # wordpair1\twordpair2-
                rhymemodell.write(wordpair[0]+"\t"+wordpair[1]+"\t"+str(wordpair[2])+"-")
        # Zeilenumbruch markiert das Ende des Eintrags
        rhymemodell.write("\n")
    # Datei schließen
    rhymemodell.close()
    
    
#----------------------------------------------------#
#     Funktionen ausführen und Dateien erstellen     #
#----------------------------------------------------#

# Nach Spalten geordnete dicts erstellen (Aus NA-Tabelle)
posdict, responsedict, stimulusdict, categorydict = read_associations("Associations.txt")
# Relationsmodell erstellen
relationdict = write_relationmodell(responsedict, stimulusdict)
# Reimmodell erstellen (zuerst dict erstellen)
write_rhymemodell(relationdict)    