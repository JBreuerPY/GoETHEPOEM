# -*- coding: utf-8 -*-

"""
1) Funktionen zum Einlesen und Verarbeiten von Dateien
2) Erstellung von Wortlisten
3) Funktionen zur Gedichtgenerierung

1)
- read_associations
- read_relationmodell
- read_rhymemodell

2)
- posdict, responsedict, stimulusdict, categorydict
- relationdict
- rhymedict
- ot_dict
- deadlist

3)
- template_to_text
- goethepoem
- interactive_poem
"""

# words
from Orthographie import *
# templates
from Templates import *
# re
import re
# choice
from random import choice

#-----------------------------------------------------------#
#    Funktionen zum Einlesen und Verarbeiten von Dateien    #
#-----------------------------------------------------------#

"#############################################################################################################"
# read_associations
"#############################################################################################################"

##############################################################################################
# Funktion zum Einlesen einer Vorverarbeiteten noun associations-Datei und zum Erstellen
# entsprechender dictionaries, zum effizienteren Suchen nach Einträgen.
# Eingabe: txt-Datei
# Ausgabe: Tupel mit dicts: (posdict, responsedict, stimulusdict, categorydict)
##############################################################################################
def read_associations(file):
    # Datei öffnen
    associations_open = open(file, encoding = "UTF-8")
    # Datei einlesen
    associations_read = associations_open.read()
    # Liste erstellen mit Zeileneinträgen
    associations_list = [i.split("\t")[:-1] for i in associations_read.split("\n") if i != ""]
    # Datei schließen
    associations_open.close()
    
    # Dictionaries erstellen, von denen man direkt auf passende Einträge zugreifen kann
    # Für jede Spalte (außer relation type) wir ein Dict erstellt
    # posdict
    posdict = {}
    for row in associations_list:
        if row[1] not in posdict:
            posdict[row[1]] = [row]
        else:
            posdict[row[1]] += [row]
    # responsedict
    responsedict = {}
    for row in associations_list:
        if row[0] not in responsedict:
            responsedict[row[0]] = [row]
        elif row[0] in responsedict:
            responsedict[row[0]] += [row]
    # stimulusdict
    stimulusdict = {}
    for row in associations_list:
        if row[3] not in stimulusdict:
            stimulusdict[row[3]] = [row]
        if row[3] in stimulusdict and row not in stimulusdict[row[3]]:
            stimulusdict[row[3]] += [row]
    # categorydict
    categorydict = {}
    for row in associations_list:
        if row[4] not in categorydict:
            categorydict[row[4]] = [row]
        else:
            categorydict[row[4]] += [row]
        
    # Ausgabe
    return posdict, responsedict, stimulusdict, categorydict


"#############################################################################################################"
# read_relationmodell
"#############################################################################################################"

##############################################################################################
# Funktion zum Einlesen einer txt-Datei (relationmodell) und zur Erstellung eines
# relationdicts: Jeder Eintrag ist ein Wort aus dem Korpus, dessen Values jeweils
# eine Liste ist, in denen alle mit dem Wort assoziierten Wörter samt POS-Tag enthalten
# sind.
# Eingabe: txt-Datei
# Ausgabe: relation_dict
##############################################################################################

def read_relationmodell(file):
    # Datei öffnen
    file_open = open(file,encoding="UTF-8")
    # Datei einlesen
    file_read = file_open.read()
    # Liste erstellen: Jeden Eintrag an Zeilenumbruch splitten
    file_entries = [entry for entry in file_read.split("\n") if entry != "" and len(entry.split("|")) == 2]
    # relationdict erstellen
    relationdict = {}
    # über jeden Eintrag iterien
    for entry in file_entries:
        # key
        dictkey = entry.split("|")[0]
        # value
        rest = entry.split("|")[1]
        # Eintrag für relationdiict erstellen
        relationdict[dictkey] = [(wordpos.split()[0], wordpos.split()[1], int(wordpos.split()[2])) for wordpos in rest.split("\t") if wordpos != ""]
    # Datei schließen
    file_open.close()
    # dict wiedergeben
    return relationdict


"#############################################################################################################"
# read_rhymemodell
"#############################################################################################################"

###############################################################################
# Funktion, die eine txt-Datei einliest und ein Reimdict ausgibt
# Eingabe: Dateiname
# Ausgabe: Reimdict
###############################################################################
def read_rhymemodell(file):
    # Datei öffnen
    rhymemodell_open = open(file,encoding="UTF-8")
    # Einlesen
    rhymemodell_read = rhymemodell_open.read()
    # Liste mit Einträgen erstellen: An Zeilenumbruch splitten
    rhymemodell_entries = [line for line in rhymemodell_read.split("\n") if line != ""]
    # Datei schließen
    rhymemodell_open.close()
    # Reimdict erstellen
    rhymedict = {}
    # über Liste mit Einträgen iterieren
    for entry in rhymemodell_entries:
        # key aus Eintrag extrahieren
        related_word = entry.split("|")[0]
        # Listenabstraktion: Den Rest des Eintrages in verschachtelte Liste überführen
        rest = [[[tuple(word.split("\t")) for word in wordpair.split("-") if word != ""] for wordpair in pospair.split("[") if wordpair != ""] for pospair in entry.split("|")[1].split("{") if pospair != ""]
        # mit key Dicteintrag erstellen
        rhymedict[related_word] = {}
        # über die "Rest"-Liste iterieren
        for element in rest:
            # Vorkommen mit entsprechender Länge dem Eintrag als values hinzufügen
            if len(element) == 2:
                rhymedict[related_word][element[0][0]] = element[1]
    # Reimdict ausgeben
    return rhymedict

#---------------------------------------------------#
#    Dateien einlesen und Dictionaries erstellen    #
#---------------------------------------------------#

# Nach Spalten geordnete dicts erstellen (Aus NA-Tabelle)
posdict, responsedict, stimulusdict, categorydict = read_associations("Associations.txt")
# relationdict
relationdict = read_relationmodell("relationmodell.txt")
# rhymedict
rhymedict = read_rhymemodell("rhymemodell.txt")

#####################
# openthesaurus.txt #
#####################

# ot_dict erstellen, zum zugreifen auf Lexikoneinträge
# Datei öffnen
ot_open = open("openthesaurus.txt", encoding = "UTF-8")
# Datei einlesen
ot_read = ot_open.read().replace("ü","ue").replace("ä","ae").replace("ö","oe").replace("Ü","Ue").replace("Ä","Ae").replace("Ö","Oe")
# Liste mit Einträgen erstellen (Ohne Vorwort und letztes (leeres) Element)
ot_split = [entry.split(";") for entry in ot_read.split("\n")[18:-1]]
# # ot_dict erstellen
ot_dict = {}
# über Liste mit Einträgen iterieren
for entry in ot_split:
    # über Wörter in Eintrag iterieren
    for word in entry:
        # Eintrag erstellen und Wörter einfügen, wenn keine Leerzeichen und keine Interpunktion vorhanden ist
        if word not in ot_dict and len(word.split()) == 1 and strip_punctuation(word) == word:
            ot_dict[word] = [tok for tok in entry if tok != word and len(tok.split()) == 1 and strip_punctuation(tok) == tok]
        # Gegebenen Falls Eintrag um Wörter erweitern, die noch nicht enthalten sind
        elif word in ot_dict and len(word.split()) == 1 and strip_punctuation(word) == word:
            ot_dict[word] += [tok for tok in entry if tok != word  and len(tok.split()) == 1 and tok not in ot_dict[word] and strip_punctuation(tok) == tok]
# Datei schließen
ot_open.close()

########################################################################################
# Eine "Deadlist" erstellen, in der hochfrequente (>1500) Reimpaare gespeichert werden #
########################################################################################
# Schritt 1: Ein dict erstellen. Jedes Reimpaar und ihre Frequenz in gesamten rhymedict
freqdict = {}
# über jedes Wort in rhymedict iterieren
for word in rhymedict:
    # über jedes POS-Paar im Eintrag iterieren
    for pospair in rhymedict[word]:
        # Über jedes Reimpaar im Eintrag iterieren
        for rhymepair in rhymedict[word][pospair]:
            # Wenn Reimpaar nicht in freqdict
            if rhymepair not in freqdict:
                # Erstelle einen Eintrag für das Reimpaar und setze Frequenz auf 1
                freqdict[rhymepair] = 1
            # sonst
            else:
                # erhöhe Frequenz um 1
                freqdict[rhymepair] += 1
# Schritt 2: Deadlist erstellen
deadlist = []
# iteriere über freqlist
for pair in freqdict:
    # Wenn Frequenz größer als 1500 ist
    if freqdict[pair] > 1500:
        # Füge Element als Tupel mit beiden Wörtern in Deadlist hinzu
        deadlist.append((pair[0],pair[1]))

#---------------------------------------------------#
#        Funktionen zur Gedichtgenerierung          #
#---------------------------------------------------#

"#############################################################################################################"
# template_to_text
"#############################################################################################################"

##############################################################################################################
# Diese Funktion befüllt ein Template mit passenden Wörtern aus dem
# Korpus.
# - Eingabe: template (2 Verse von \n getrennt), feed (Titel), rhymepair (Wort1,Wort2,Level), used_words
# template (2 Verse von \n getrennt)
# - Ausgabe: Zwei Gedichtstrophen (mit selbem Versmaß als Liste mit Wörtern), used_words (erweiterte Liste)
##############################################################################################################
def template_to_text(template, feed, rhymepair, used_words):
    # Template in einzelne token splitten (Interpunktion entfernen)
    # Aktuelles Template
    template_toks = strip_punctuation(template).split()
    
    if type(used_words) != list:
        used_words_extended = used_words.split()+[rhymepair[0],rhymepair[1]]
    # Erweiterbare Liste mit bereits verwendeten Wörtern
    else:
        used_words_extended = used_words+[rhymepair[0],rhymepair[1]]
    
    # Reimwörter
    REIMfirst = rhymepair[0]
    REIMsecond = rhymepair[1]
    
    # Interpunktionsschema in Listen speichern
    punct = []
    for word in template.split():
        if word[-1] in punctuation:
            punct.append(word[-1])
        else:
            punct.append("")
            
    # Templates ausfüllen, indem ein zufälliges Wort aus der enstprechenden Liste gewählt wird
    # über jedes Element des Templates iterien
    for word in template_toks:
        # Titel (feed)
        if word == "FEED":
            if feed in [word[0] for word in posdict["NN"]]+list(stimulusdict.keys()):
                template_toks[template_toks.index(word)] = feed
                used_words_extended.append(feed)
            else:
                # wenn Reimwort 1 in responsedict vorhanden
                if feed in responsedict:
                    candidates = [word[3] for word in responsedict[feed] if word[3] not in used_words_extended]
                # sonst wähle aus stimulusdict
                else:
                    candidates = [word[0] for word in stimulusdict[feed] if word[0] not in used_words_extended and word[1] == "NN"]
                # wenn Kandidaten gefunden wurden, wähle einen aus und befülle damit den Platz im Template
                if candidates != []:
                    feed_choice = choice(candidates)
                else:
                    feed_choice = choice([word[0] for word in relationdict[feed] if word[1] == "NN" and word[0] not in used_words_extended])
                template_toks[template_toks.index(word)] = feed_choice
                used_words_extended.append(feed_choice)
                
        # Associations
        # Reim 1
        elif word == "REIMfirst":
            template_toks[template_toks.index(word)] = REIMfirst
        # Reim 2
        elif word == "REIMsecond":
            template_toks[template_toks.index(word)] = REIMsecond
            
        # NNrhymefirst
        elif word == "NNrhymefirst":
            # wenn Reimwort 1 in relationdict vorhanden
            if REIMfirst in relationdict:
                # Kandidaten auswählen, die mit Reimwort 1 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "NN" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "NN"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "NN" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "NN"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                NNrhymefirst = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 1 in relationdict vorhanden
                if REIMfirst in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "NN" and word[0] not in used_words_extended]
                    # Liste relierter Nomen erstellen
                    related_nn = [word[0] for word in relationdict[REIMfirst] if word[1] == "NN"]
                # wenn Reimwort 1 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "NN" and word[0] not in used_words_extended]
                    # Liste relierter Nomen erstellen
                    related_nn = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "NN"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_nn and tok not in used_words_extended] for word in related_nn if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    NNrhymefirst = choice(candidates+related_synonyms)
                except:
                    # Wähle irgendein Nomen aus Korpus
                    NNrhymefirst = choice([word[0] for word in posdict["NN"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = NNrhymefirst
            # Wort in used_words_extended speichern
            used_words_extended.append(NNrhymefirst)
  
        # NNrhymesecond
        elif word == "NNrhymesecond":
            # wenn Reimwort 2 in relationdict vorhanden
            if REIMsecond in relationdict:
                # Kandidaten auswählen, die mit Reimwort 2 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "NN" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "NN"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "NN" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "NN"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                NNrhymesecond = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 2 in relationdict vorhanden
                if REIMsecond in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "NN" and word[0] not in used_words_extended]
                    # Liste relierter Nomen erstellen
                    related_nn = [word[0] for word in relationdict[REIMsecond] if word[1] == "NN"]
                # wenn Reimwort 2 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "NN" and word[0] not in used_words_extended]
                    # Liste relierter Nomen erstellen
                    related_nn = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "NN"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_nn and tok not in used_words_extended] for word in related_nn if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    NNrhymesecond = choice(candidates+related_synonyms)
                except:
                    # Wähle irgendein Nomen aus Korpus
                    NNrhymesecond = choice([word[0] for word in posdict["NN"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = NNrhymesecond
            # Wort in used_words_extended speichern
            used_words_extended.append(NNrhymesecond)
            
        # ADJXrhymefirst
        elif word == "ADJXrhymefirst":
            # wenn Reimwort 1 in relationdict vorhanden
            if REIMfirst in relationdict:
                # Kandidaten auswählen, die mit Reimwort 1 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                ADJXrhymefirst = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 1 in relationdict vorhanden
                if REIMfirst in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX"]
                # wenn Reimwort 1 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_adjx and tok not in used_words_extended] for word in related_adjx if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    ADJXrhymefirst = choice(candidates+related_synonyms)
                except:
                    # Wähle ein zufälliges Adjektiv aus dem Korpus
                    ADJXrhymefirst = choice([word[0] for word in posdict["ADJX"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = ADJXrhymefirst
            # Wort in used_words_extended speichern
            used_words_extended.append(ADJXrhymefirst)
            
        # ADJXrhymesecond
        elif word == "ADJXrhymesecond":
            # wenn Reimwort 2 in relationdict vorhanden
            if REIMsecond in relationdict:
                # Kandidaten auswählen, die mit Reimwort 2 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                ADJXrhymesecond = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 2 in relationdict vorhanden
                if REIMsecond in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX"]
                # wenn Reimwort 2 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_adjx and tok not in used_words_extended] for word in related_adjx if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    ADJXrhymesecond = choice(candidates+related_synonyms)
                except:
                    # Wähle ein zufälliges Adjektiv aus dem Korpus
                    ADJXrhymesecond = choice([word[0] for word in posdict["ADJX"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = ADJXrhymesecond
            # Wort in used_words_extended speichern
            used_words_extended.append(ADJXrhymesecond)
            
        # VVINFrhymefirst
        elif word == "VVINFrhymefirst":
            # wenn Reimwort 1 in relationdict vorhanden
            if REIMfirst in relationdict:
                # Kandidaten auswählen, die mit Reimwort 1 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "VVINF" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "VVINF"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "VVINF" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "VVINF"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                VVINFrhymefirst = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 1 in relationdict vorhanden
                if REIMfirst in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen und einen wählen
                    candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "VVINF" and word[0] not in used_words_extended]
                    # Liste relierter Verben erstellen
                    related_vvinf = [word[0] for word in relationdict[REIMfirst] if word[1] == "VVINF"]
                # wenn Reimwort 1 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen und einen wählen
                    candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "VVINF" and word[0] not in used_words_extended]
                    # Liste relierter Verben erstellen
                    related_vvinf = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "VVINF"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_vvinf and tok not in used_words_extended] for word in related_vvinf if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    VVINFrhymefirst = choice(candidates+related_synonyms)
                except:
                    # Wähle ein zufälliges Verb aus dem Korpus
                    VVINFrhymefirst = choice([word[0] for word in posdict["VVINF"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = VVINFrhymefirst
            # Wort in used_words_extended speichern
            used_words_extended.append(VVINFrhymefirst)
            
        # VVINFrhymesecond
        elif word == "VVINFrhymesecond":
            # wenn Reimwort 2 in relationdict vorhanden
            if REIMsecond in relationdict:
                # Kandidaten auswählen, die mit Reimwort 2 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "VVINF" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "VVINF"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "VVINF" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "VVINF"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                VVINFrhymesecond = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 2 in relationdict vorhanden
                if REIMsecond in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "VVINF" and word[0] not in used_words_extended]
                    # Liste relierter Verben erstellen
                    related_vvinf = [word[0] for word in relationdict[REIMsecond] if word[1] == "VVINF"]
                # wenn Reimwort 2 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "VVINF" and word[0] not in used_words_extended]
                    # Liste relierter Verben erstellen
                    related_vvinf = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "VVINF"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_vvinf and tok not in used_words_extended] for word in related_vvinf if word in ot_dict] for item in sublist]
                try:
                    # Aus Kandidaten- und Synonymenliste ein Wort wählen
                    VVINFrhymesecond = choice(candidates+related_synonyms)
                except:
                    # Wähle ein zufälliges Verb aus dem Korpus
                    VVINFrhymesecond = choice([word[0] for word in posdict["VVINF"]])
            # in Wort Template einfügen
            template_toks[template_toks.index(word)] = VVINFrhymesecond
            # Wort in used_words_extended speichern
            used_words_extended.append(VVINFrhymesecond)
            
        # Eigene Listen
        # CONJ
        elif word == "CONJ":
            template_toks[template_toks.index(word)] = choice(CONJ)
        # ADPDAT
        elif word == "ADPDAT":
            template_toks[template_toks.index(word)] = choice(ADPDAT)
        # MODVERB13SG
        elif word == "MODVERB13SG":
            template_toks[template_toks.index(word)] = choice(MODVERB13SG)
        # MODVERB13PL
        elif word == "MODVERB13PL":
            template_toks[template_toks.index(word)] = choice(MODVERB13PL)
        # MODVERBPAST13SG
        elif word == "MODVERBPAST13SG":
            template_toks[template_toks.index(word)] = choice(MODVERBPAST13SG)
        # MODVERBPAST13PL
        elif word == "MODVERBPAST13PL":
            template_toks[template_toks.index(word)] = choice(MODVERBPAST13PL)
        # MODVERBCOND13PL
        elif word == "MODVERBCOND13PL":
            template_toks[template_toks.index(word)] = choice(MODVERB13PL)
        # VERBREFLEX3SG
        elif word == "VERBREFLEX3SG":
            template_toks[template_toks.index(word)] = choice(VERBREFLEX3SG)
        # ADVTEMP
        elif word == "ADVTEMP":
            ADVTEMP_choice = choice([word for word in ADVTEMP if word not in used_words_extended])
            template_toks[template_toks.index(word)] = ADVTEMP_choice
            used_words_extended.append(ADVTEMP_choice)
        # ADVSOFORT
        elif word == "ADVSOFORT":
            template_toks[template_toks.index(word)] = choice(ADVSOFORT)
        # ADVam
        elif word == "ADVam":
            ADVam_choice = choice([word for word in ADVam if word not in used_words_extended])
            template_toks[template_toks.index(word)] = ADVam_choice
            used_words_extended.append(ADVam_choice)
        # ADVPAST
        elif word == "ADVPAST":
            template_toks[template_toks.index(word)] = choice(ADVPAST)
        # ADVPRES
        elif word == "ADVPRES":
            template_toks[template_toks.index(word)] = choice(ADVPRES)
        # ADVFUT
        elif word == "ADVFUT":
            template_toks[template_toks.index(word)] = choice(ADVFUT)
        # CONJBUT
        elif word == "CONJBUT":
            template_toks[template_toks.index(word)] = choice(CONJBUT)
        # CONJDARUM
        elif word == "CONJDARUM":
            template_toks[template_toks.index(word)] = choice(CONJDARUM)
        # VERBEXTRA
        elif word == "VERBEXTRA":
            template_toks[template_toks.index(word)] = choice(VERBEXTRA)
        # CONJWENN
        elif word == "CONJWENN":
            template_toks[template_toks.index(word)] = choice(CONJWENN)
        # VERBEXTRA3SG
        elif word == "VERBEXTRA3SG":
            template_toks[template_toks.index(word)] = choice(VERBEXTRA3SG)
        # VERBACC3SG
        elif word == "VERBACC3SG":
            template_toks[template_toks.index(word)] = choice(VERBACC3SG)
        # VERBACC13PL
        elif word == "VERBACC13PL":
            template_toks[template_toks.index(word)] = choice(VERBACC13PL)
        # VERBACCDATS3SG
        elif word == "VERBACCDATS3SG":
            template_toks[template_toks.index(word)] = choice(VERBACCDATS3SG)
        # VERBACCDAT3SG
        elif word == "VERBACCDAT3SG":
            template_toks[template_toks.index(word)] = choice(VERBACCDAT3SG)
        # VERBACCDAT13PL
        elif word == "VERBACCDAT13PL":
            template_toks[template_toks.index(word)] = choice(VERBACCDAT13PL)         
            
    # Kontextabhängiges Umwandeln
    # Über Liste mit bereits teilweise umgewandelten Templates iterieren
    for word in template_toks:
        # Adjektive
        # ADJXofx: Wählt ein reliertes Adjektiv zum xten Wort im Template (x=Index)
        if "ADJXof" in word:
            try:
                # Wort x bestimmen
                word_x = template_toks[int(word[-1])]
                # wenn Wort x nicht in relationdict
                if word_x not in relationdict:
                    # Wähle ein Synonym aus ot_dict, dass in relationdict vorhanden ist
                    word_x = choice([synonym for synonym in ot_dict[word_x] if synonym in relationdict])
                # wenn wort-x in stimulusdict vorhanden
                if word_x in stimulusdict:
                    candidates = [word[0] for word in stimulusdict[word_x] if word[0] not in used_words_extended and word[1] == "ADJX"]
                # Andernfalls
                else:
                    # wähle mit Wort-x relierte Adjektive und füge sie candidates hinzu
                    candidates = [word[0] for word in relationdict[word_x] if word[0] not in used_words_extended and word[1] == "ADJX"]
                    # Wenn candidates leer ist
                    if candidates == []:
                        # wähle mit dem Titel relierte Adjektive und füge sie candidates hinzu
                        candidates += [word[0] for word in relationdict[feed] if word[0] not in used_words_extended and word[1] == "ADJX"]
                # Wenn candidates nicht leer ist
                if candidates != []:
                    # wähle einen zufälligen Kandidaten aus
                    ADJXof = choice(candidates)
                else:
                    # wähle einen zufälligen Kandidaten aus der Liste mit Adjektiven
                    ADJXof = choice([entry[0] for entry in posdict["ADJX"]])
            except:
                ADJXof = choice([word[0] for word in posdict["ADJX"] if word[0] not in used_words])
            # Adjektiv in Template einfügen und ersetzen
            template_toks[template_toks.index(word)] = ADJXof
            # Adjektiv der Liste mit bereits verwendeten Wörtern hinzufügen
            used_words_extended.append(ADJXof)    
            
        # ADJXrhymefirstE
        elif word == "ADJXrhymefirstE":
            # wenn Reimwort 1 in relationdict vorhanden
            if REIMfirst in relationdict:
                # Kandidaten auswählen, die mit Reimwort 1 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                ADJXrhymefirstE = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 1 in relationdict vorhanden
                if REIMfirst in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[REIMfirst] if word[1] == "ADJX"]
                # wenn Reimwort 1 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMfirst = choice([synonym for synonym in ot_dict[REIMfirst] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 1 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[synonymREIMfirst] if word[1] == "ADJX"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_adjx and tok not in used_words_extended] for word in related_adjx if word in ot_dict] for item in sublist]
                # Aus Kandidaten- und Synonymenliste ein Wort wählen
                ADJXrhymefirstE = choice(candidates+related_synonyms)
            # Wort in Template einfügen
            if ADJXrhymefirstE[-1] != "e":
                template_toks[template_toks.index(word)] = ADJXrhymefirstE+"e"
            else:
                template_toks[template_toks.index(word)] = ADJXrhymefirstE
            # Wort in used_words_extended speichern
            used_words_extended.append(ADJXrhymefirstE)
            
        # ADJXrhymesecondE
        elif word == "ADJXrhymesecondE":
            # wenn Reimwort 2 in relationdict vorhanden
            if REIMsecond in relationdict:
                # Kandidaten auswählen, die mit Reimwort 2 und Titel reliert sind und nicht in used_words_extended vorkommen
                candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Andernfalls
            else:
                # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                # Kandidaten wählen
                candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended and word[0] in [word[0] for word in relationdict[feed] if word[1] == "ADJX"]]
            # Wenn Kandidaten gefunden wurden
            if candidates != []:
                # Kandidaten auswählen
                ADJXrhymesecondE = choice(candidates)
            # Wenn keine Kandidaten gefunden wurden
            else:
                # wenn Reimwort 2 in relationdict vorhanden
                if REIMsecond in relationdict:
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[REIMsecond] if word[1] == "ADJX"]
                # wenn Reimwort 2 nicht in relationdict vorhanden
                else:
                    # Suche ein Synonym aus ot_dict, dass in relationdict vorkommt
                    synonymREIMsecond = choice([synonym for synonym in ot_dict[REIMsecond] if synonym in relationdict])
                    # Kandidaten auswählen, die nur mit Reimwort 2 reliert sind und nicht in used_words_extended vorkommen
                    candidates = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX" and word[0] not in used_words_extended]
                    # Liste relierter Adjektive erstellen
                    related_adjx = [word[0] for word in relationdict[synonymREIMsecond] if word[1] == "ADJX"]
                # Liste mit synonymen erstellen
                related_synonyms = [item for sublist in [[tok for tok in ot_dict[word] if tok not in related_adjx and tok not in used_words_extended] for word in related_adjx if word in ot_dict] for item in sublist]
                # Aus Kandidaten- und Synonymenliste ein Wort wählen
                ADJXrhymesecondE = choice(candidates+related_synonyms)
            # Wort in Template einfügen
            if ADJXrhymesecondE[-1] != "e":
                template_toks[template_toks.index(word)] = ADJXrhymesecondE+"e"
            else:
                template_toks[template_toks.index(word)] = ADJXrhymesecondE
            # Wort in used_words_extended speichern
            used_words_extended.append(ADJXrhymesecondE)
            
        
        # Artikel                                
        # Artikel: Zufällig, Nominativ
        if word == "DET1":
            template_toks[template_toks.index(word)] = choice([get_det(template_toks[template_toks.index(word)+1])[0][0],
                                                 get_det(template_toks[template_toks.index(word)+1])[1][0]])
        # Artikel: Unbestimmt, Nominativ
        elif word == "DETINDET1":
            template_toks[template_toks.index(word)] = get_det(template_toks[template_toks.index(word)+1])[1][0]
        # Artikel: Unbestimmt, Nominativ, bezieht sich auf das übernächste Wort
        elif word == "DETINDET2":
            template_toks[template_toks.index(word)] = get_det(template_toks[template_toks.index(word)+2])[1][0]
        # DETofx: Wählt den passenden bestimmten Artikel zum xten Wort im Template (x=Index)
        elif "DETof" in word:
            template_toks[template_toks.index(word)] = get_det(template_toks[int(word[-1])])[0][0]
            
        # Artikel: DETREIMfirst (Bezieht sich auf erstes Reimwort), Nominativ, auch als Relativpronomen verwendbar
        elif word == "DETREIMfirst":
            template_toks[template_toks.index(word)] = get_det(REIMfirst)[0][0]
            
        # Artikel: Bestimmt, Nominativ
        elif word == "DETDET1":
            template_toks[template_toks.index(word)] = get_det(template_toks[template_toks.index(word)+1])[0][0]
        # Artikel: Bestimmt, Nominativ, bezieht sich auf das übernächste Wort
        elif word == "DETDET2":
            template_toks[template_toks.index(word)] = get_det(template_toks[template_toks.index(word)+2])[0][0]
        # Artikel: Bestimmt, Dativ
        elif word == "DETDETDAT1":
            template_toks[template_toks.index(word)] = get_det(template_toks[template_toks.index(word)+1])[0][2]
        # Artikel: Zufällig, Akkusativ
        elif word == "DETACC1":
            template_toks[template_toks.index(word)] = choice([get_det(template_toks[template_toks.index(word)+1])[0][1], 
                                                 get_det(template_toks[template_toks.index(word)+1])[1][1]])
            
        # Personalpronomen, Nominativ: er/sie/es
        # bezieht sich auf xtes Wort im Template
        # PRONNOMFEED1
        if "PRONNOMof" in word:
            if get_gender(template_toks[int(word[-1])]) == "MASC":
                pronnom = "er"
            elif get_gender(template_toks[int(word[-1])]) == "FEM":
                pronnom = "sie"
            elif get_gender(template_toks[int(word[-1])]) == "NEUT":
                pronnom = "es"
            else: 
                pronnom = "es"
            template_toks[template_toks.index(word)] = pronnom
            
    # Interpunktion wiederherstellen
    for element in punct:
        if element != "":
            template_toks[punct.index(element)] += element
            template_toks[punct.index(element)] = template_toks[punct.index(element)].replace(",,",",")
    
    # Template in 2 Verse aufteilen und jeweils als Liste mit Wörtern speichern
    vers_1 = template_toks[:template_toks.index(REIMfirst+template.split("\n")[0][-1])+1]
    vers_2 = template_toks[template_toks.index(REIMfirst+template.split("\n")[0][-1])+1:]
    
    # Versmaß angleichen
    # Wenn Versmaße gleich sind
    if get_syllables(" ".join(vers_1)) == get_syllables(" ".join(vers_2)):
        # Ausgabe
        return " ".join(vers_1), " ".join(vers_2), used_words_extended
    # Andernfalls
    else:
        try:
            # Rekursives Abarbeiten
            return template_to_text(template, feed, rhymepair, used_words)
        except:
            # Ausgabe
            return " ".join(vers_1), " ".join(vers_2), used_words_extended
    

"#############################################################################################################"
# goethepoem
"#############################################################################################################"

##############################################################################
# Funktion zu Generierung eines Gedichts. 
# - Eingabe: Titel bzw. Feedwort
# - Ausgabe: Gedicht (Titel + 4 Strophen als String)
##############################################################################
def goethepoem(title_feed):
    # Prüfe, ob eingegebener Titel in Korpus ist oder nicht
    # wenn nicht wähle ein zufälliges Wort aus, anstelle der Eingabe
    title = ""
    if title_feed not in relationdict:
        try:
            # Prüfe, ob Synonyme Vorhanden sind
            if title_feed in ot_dict:
                # Nehme eines der Synonyme als Titel
                possible_titles = [synonym for synonym in ot_dict[title_feed] if synonym in relationdict]
                if possible_titles != []:
                    # Titel wählen
                    title = choice(possible_titles)
                    # Ausgegebener Titel
                    title_return = title+" und "+title_feed
            else:
                # Zufällig einen Titel aus Wörtern des Korpus wählen
                title = choice(list(relationdict.keys()))
                # Ausgegebener Titel
                title_return = title+" oder "+title_feed
        except:
            # Zufällig einen Titel aus Wörtern des Korpus wählen
            title = choice(list(relationdict.keys()))
            # Ausgegebener Titel
            title_return = title+" oder "+title_feed

    else:
        # wenn Wort in Korpus, dann wähle dieses
        title = title_feed
        # Ausgegebener Titel
        title_return = title
        
    if title == "":
        # Zufällig einen Titel aus Wörtern des Korpus wählen
        title = choice(list(relationdict.keys()))
        # Ausgegebener Titel
        title_return = title+" oder "+title_feed
                
    # Reimpaare auswählen
    # Versuche Reimpaare zu finden
    try:
        # Paar 1
        # Liste mit Tuppeln mit Reimpaaren und POS-Paaren erstellen (Level 1 = ab 25 Punkte aufwärts)
        pair_1_lvl_1 = [[(rhymepair,pospair) for rhymepair in rhymedict[title][pospair] if int(rhymepair[-1]) >= 25 and (rhymepair[0],rhymepair[1]) not in deadlist and (rhymepair[1],rhymepair[0]) not in deadlist] for pospair in rhymedict[title] if pospair in possible_combinations]
        # Liste mit Tuppeln mit Reimpaaren und POS-Paaren erstellen (Level 1 = ab 20 Punkte abwärts)
        pair_1_lvl_2 = [[(rhymepair,pospair) for rhymepair in rhymedict[title][pospair] if int(rhymepair[-1]) <= 20 and (rhymepair[0],rhymepair[1]) not in deadlist and (rhymepair[1],rhymepair[0]) not in deadlist] for pospair in rhymedict[title] if pospair in possible_combinations]
        # versuche aus Level 1 relierte POS-und Reimpaare zu wählen
        try:
            # zufällige Tupel auswählen
            pair_1 = choice(choice(pair_1_lvl_1))
            # POS-Paar 1
            pospair1 = pair_1[1]
            # Reimpaar 1
            rhymepair1 = pair_1[0]
        # andenfalls: Wähle aus Level 2 relierte POS-und Reimpaare
        except:
            # zufällige Tupel auswählen
            pair_1 = choice(choice(pair_1_lvl_2))
            # POS-Paar 1
            pospair1 = pair_1[1]
            # Reimpaar 1
            rhymepair1 = pair_1[0]
        # Paar 2
        # Liste mit Tuppeln mit Reimpaaren und POS-Paaren erstellen (Level 1 = ab 25 Punkte aufwärts)
        pair_2_lvl_1 = [[(rhymepair,pospair) for rhymepair in rhymedict[title][pospair] if int(rhymepair[-1]) >= 25 and rhymepair[0] not in rhymepair1 and rhymepair[1] not in rhymepair1 and (rhymepair[0],rhymepair[1]) not in deadlist and (rhymepair[1],rhymepair[0]) not in deadlist] for pospair in rhymedict[title] if pospair in possible_combinations and pospair != pospair1]
        # Liste mit Tuppeln mit Reimpaaren und POS-Paaren erstellen (Level 1 = ab 20 Punkte abwärts)
        pair_2_lvl_2 = [[(rhymepair,pospair) for rhymepair in rhymedict[title][pospair] if int(rhymepair[-1]) <= 20 and rhymepair[0] not in rhymepair1 and rhymepair[1] not in rhymepair1 and (rhymepair[0],rhymepair[1]) not in deadlist and (rhymepair[1],rhymepair[0]) not in deadlist] for pospair in rhymedict[title] if pospair in possible_combinations and pospair != pospair1]
        # versuche aus Level 1 relierte POS-und Reimpaare zu wählen
        try:
            # zufällige Tupel auswählen
            pair_2 = choice(choice(pair_2_lvl_1))
            # POS-Paar 2
            pospair2 = pair_2[1]
            # Reimpaar 2
            rhymepair2 = pair_2[0]
        # andenfalls: Wähle aus Level 2 relierte POS-und Reimpaare
        except:
            # zufällige Tupel auswählen
            pair_2 = choice(choice(pair_2_lvl_2))
            # POS-Paar 2
            pospair2 = pair_2[1]
            # Reimpaar 2
            rhymepair2 = pair_2[0]
    # Ausnahmeregelung: Wenn keine Reimpaare gefunden wurden
    except:
        # rekursives abarbeiten (Es sollte für jedes Wort genug Reimpaare geben)
        return goethepoem(title_feed)

    # Templates wählen
    templates = []
    # Über jedes der beiden POS-Paare iterieren
    for pospair in [pospair1, pospair2]:
        # Für das erste Paar
        if pospair == pospair1:
            # Weise templates_list_vers Templates für die ersten zwei Verse zu
            templates_list_vers = templates_list[0]
        # Für das zweite Paar
        elif pospair == pospair2:
            # Weise templates_list_vers Templates für die letzten zwei Verse zu
            templates_list_vers = templates_list[1]
        # Wenn POS-Paar vom Typ NN und NN ist
        if pospair == ("NN","NN"):
            # Wähle das entsprechende Template aus und füge es templates hinzu
            templates.append(templates_list_vers[0])
        # Für jedes Paar so weitermachen...
        elif pospair == ("NN","ADJX"):
            templates.append(templates_list_vers[1])
        elif pospair == ("NN","VVINF"):
            templates.append(templates_list_vers[2])
        elif pospair == ("ADJX","ADJX"):
            templates.append(templates_list_vers[3])
        elif pospair == ("ADJX","NN"):
            templates.append(templates_list_vers[4])
        elif pospair == ("ADJX","VVINF"):
            templates.append(templates_list_vers[5])
        elif pospair == ("VVINF","VVINF"):
            templates.append(templates_list_vers[6])
        elif pospair == ("VVINF","ADJX"):
            templates.append(templates_list_vers[7])
        elif pospair == ("VVINF","NN"):
            templates.append(templates_list_vers[8])

    # Templates befüllen
    try:
        vers_1, vers_2, used_words_1 = template_to_text(templates[0], title, rhymepair1,[])
    except:
        vers_1, vers_2, used_words_1 = template_to_text(templates[0], title, rhymepair1,[])
    try:
        vers_3, vers_4, used_words_2 = template_to_text(templates[1], title, rhymepair2,used_words_1)
    except:
        vers_3, vers_4, used_words_2 = template_to_text(templates[1], title, rhymepair2,used_words_1)
    # Erstes Wort in Vers 1 großschreiben
    vers_1 = vers_1[0].capitalize()+vers_1[1:]
    # Je zweiten Vers großschreiben, wenn er ein neuer Satz ist
    if vers_1[-1] in ".!:?;":
        vers_2 = vers_2[0].capitalize()+vers_2[1:]
    if vers_2[-1] in ".!:?;":
        vers_3 = vers_3[0].capitalize()+vers_3[1:]
    if vers_3[-1] in ".!:?;":
        vers_4 = vers_4[0].capitalize()+vers_4[1:]
    
    try:
        if get_syllables(vers_1) == get_syllables(vers_3):
            # gebe das Gedicht aus
            return title_return+"\n\n"+vers_1+"\n"+vers_2+"\n"+vers_3+"\n"+vers_4
        else:
            return goethepoem(title_feed)
    except:
        # gebe das Gedicht aus
        return title_return+"\n\n"+vers_1+"\n"+vers_2+"\n"+vers_3+"\n"+vers_4
    
    
"#############################################################################################################"
# interactive_poem
"#############################################################################################################"

####################################################
# Funktion, die interaktiv, mit einem gegebenen
# User-Input ein Gedicht generiert
####################################################
def interactive_poem():
    # Eingabe
    feed = input("Eingabe: ")
    # Ausgabe
    return "---------------------------------\n\n"+goethepoem(feed)    