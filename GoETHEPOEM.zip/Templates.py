# -*- coding: utf-8 -*-

"""
In diesem Modul sind Templates und Listen zur Erweiterung des Sytaktischen Sets gespeichert
"""

from Orthographie import strip_punctuation

######################################################################
# Wortlisten zur Erweiterung des syntaktischen Sets
######################################################################

CONJ = ["und", "oder"]
ADPDAT = ["an", "in", "vor", "über", "auf"]
MODVERB13SG = ["möchte", "will", "darf", "kann", "muss", "soll"]
MODVERBPAST13SG = ["mochte", "wollte", "durfte", "konnte", "musste", "sollte"]
MODVERBPAST13PL = ["mochten", "wollten", "durften", "konnten", "mussten", "sollten"]
MODVERB13PL = ["möchten", "wollen", "dürfen", "können", "müssen", "sollen"]
MODVERBCOND13PL = ["wollten", "dürften", "könnten", "müssten", "sollten"]
ADVTEMP = ['manchmal', 'immer', 'wieder', 'oft', 'selten', 'gelegentlich']
ADVPAST = ['anfangs', 'damals', 'eben', 'einmal', 'früher', 'gestern', 'neulich', 
            'seither', 'soeben', 'vorgestern', 'vorhin']
ADVPRES = ['augenblicklich', 'gegenwärtig', 'gerade', 'heute', 'heutzutage', 'jetzt', 'nun', 'sofort']
ADVFUT = ['bald', 'demnächst', 'morgen', 'übermorgen', 'später']
CONJBUT = ["und", "aber", "doch"]
CONJDARUM = ["darum", "deshalb", "deswegen"]
VERBEXTRA = ["sagen", "machen", "verallgemeinern", "schreiben", "annehmen", "sehen", "ausdrücken", "behaupten"]
CONJWENN = ["sobald", "wenn", "sofern", "bevor"]
VERBEXTRA3SG = ["sagt", "behauptet", "erwähnt", "schreibt"]
VERBREFLEX3SG = ["freut", "schämt", "sieht", "liebt", "hasst", "bewundert", "aufregt", "entschuldigt", "fürchtet", "wundert", "verbeugt",
                "ändert", "anzieht", "setzt", "schminkt", "zeigt"]
ADVam = ["Morgen", "Tag", "Abend", "Mittag", "Nachmittag", "Morgengrauen"]
ADVim = ["Sommer", "Winter", "Frühling", "Herbst", "Wald", "Meer", "Sand"]
ADVSOFORT = ["sofort", "wieder", "plötzlich", "gleich", "irgendwann"]
VERBACC3SG = ["hat", "erhält", "besitzt", "sieht", "kennt", "bekommt", "isst", "fragt", "liebt", "besucht", "untersucht",
                "mag", "hasst", "versenkt", "sprengt", "erschreckt", "braucht", "entfernt", "kauft", "verändert"]
VERBACC13PL = ["haben", "erhalten", "besitzen", "sehen", "kennen", "bekommen", "essen", "fragen", "lieben", "besuchen", "untersuchen",
                "mögen", "hassen", "versenken", "sprengen", "erschrecken", "brauchen", "entfernen", "kaufen"]
VERBACCDATS3SG = ["nennt", "schimpft", "gibt", "schickt", "sendet", "schenkt",
                 "empfehlt", "erklärt", "stiehlt", "verbietet", "wünscht", "zeigt"]
VERBACCDAT3SG = ["nennt", "schimpft", "aufschwatzt", "gibt", "aufdrückt", "auferlegt", "schickt", "sendet", "schenkt",
                 "empfehlt", "erklärt", "stiehlt", "verbietet", "wünscht", "zeigt"]
VERBACCDAT13PL = ["nennen", "schimpfen", "aufschwatzen", "geben", "aufdrücken", "auferlegen", "schicken", "senden", "schenken",
                 "empfehlen", "erklären", "stehlen", "verbieten", "wünschen", "zeigen"]
# Liste aller in den Wortlisten enthaltenen Wörter
list_words = CONJ+ADPDAT+MODVERB13SG+MODVERBPAST13SG+MODVERBPAST13PL+MODVERB13PL+MODVERBCOND13PL+ADVTEMP+ADVPAST+ADVPRES+ADVFUT+CONJBUT+CONJDARUM+VERBEXTRA+CONJWENN+VERBEXTRA3SG+VERBREFLEX3SG+ADVam+ADVim+ADVSOFORT+VERBACC3SG+VERBACC13PL+VERBACCDATS3SG+VERBACCDAT3SG+VERBACCDAT13PL

############################################################################
# Templates für einen Vierzeiler
# - Jeder Vers ist von einem Zeilenumbruch getrennt
# - Vor den ersten zwei Versen steht eine 1, vor den letzten beiden, eine 2
############################################################################
# NN und NN
templates_NN_NN = """1 ADVTEMP egal ob NNrhymefirst oder REIMfirst,
denn DETINDET1 FEED ist ADJXrhymesecond wie DETDET1 REIMsecond.
2 ADVTEMP so ADJXrhymefirst wie DETDET1 REIMfirst,
DETREIMfirst VVINFrhymesecond MODVERB13SG wie DETINDET1 REIMsecond."""
# NN und ADJX
templates_NN_ADJX = """1 am ADVam so ADJXrhymefirst wie DETDET1 REIMfirst,
und am ADVam wie DETINDET1 NNrhymesecond so REIMsecond.
2 und plötzlich VERBACC3SG man DETACC1 REIMfirst,
DETREIMfirst ist wie DETINDET1 NNrhymesecond so REIMsecond."""
# NN und VVINF
templates_NN_VVINF = """1 ADJXrhymefirst und ADJXrhymefirst wie DET1 REIMfirst,
DETREIMfirst VERBACC13PL MODVERB13SG was wir REIMsecond.
2 ADJXrhymefirst und ADJXrhymefirst wie DETINDET1 REIMfirst,
DETREIMfirst VERBACC13PL MODVERB13SG, was wir REIMsecond."""
# ADJX und ADJX
templates_ADJX_ADJX = """1 ADVTEMP wie DETINDET1 NNrhymefirst so REIMfirst,
DETof3 ADVTEMP VVINFrhymesecond MODVERB13SG, so REIMsecond.
2 ADVTEMP wie DETINDET1 NNrhymefirst so REIMfirst,
DETof3 ADVTEMP VVINFrhymesecond MODVERB13SG, so REIMsecond."""
# ADJX und NN
templates_ADJX_NN = """1 ADVTEMP wie DETINDET1 NNrhymefirst so REIMfirst,
beim VVINFrhymesecond wie DETDET2 ADJXrhymesecondE REIMsecond.
2 ADVTEMP wie DETINDET1 NNrhymefirst so REIMfirst,
wie DETINDET1 NNrhymesecond oder DETDET2 ADJXrhymesecondE REIMsecond."""
# ADJX und VVINF
templates_ADJX_VVINF = """1 wie DETINDET1 NNrhymefirst so ADJXof2 und REIMfirst,
MODVERB13SG DETINDET1 NNrhymesecond ADVTEMP REIMsecond.
2 und ADVTEMP wie DETINDET1 NNrhymefirst so REIMfirst,
dass es zu ADJXrhymesecond wird um zu REIMsecond."""
# VVINF und VVINF
templates_VVINF_VVINF = """1 ADVTEMP MODVERB13SG DETINDET1 NNrhymefirst REIMfirst,
wenn PRONNOMof3 zu ADJXrhymefirst ist, um zu REIMsecond.
2 denn ADJXrhymefirst ist es wenn wir REIMfirst,
wie DETDET2 ADJXrhymesecondE NNrhymesecond beim REIMsecond."""
# VVINF und ADJX
templates_VVINF_ADJX = """1 ADVTEMP wenn wieder alle REIMfirst,
dann wird DETDET2 ADJXrhymesecondE NNrhymesecond REIMsecond.
2 auch DETDET2 ADJXrhymefirstE NNrhymefirst MODVERB13SG REIMfirst,
wie DETINDET1 NNrhymesecond am ADVam so REIMsecond."""
# VVINF und NN
templates_VVINF_NN = """1 auch DETDET2 ADJXrhymefirstE NNrhymefirst MODVERB13SG REIMfirst,
wie DETINDET1 NNrhymesecond oder auch DETDET1 REIMsecond.
2 auch DETDET2 ADJXrhymefirstE NNrhymefirst MODVERB13SG REIMfirst,
wie DETINDET1 NNrhymesecond oder auch DETDET1 REIMsecond."""

# Liste aller Kombinationen
possible_combinations = [("NN","NN"),("NN","ADJX"),("NN","VVINF"),
                         ("ADJX","ADJX"),("ADJX","NN"),("ADJX","VVINF"),
                         ("VVINF","VVINF"),("VVINF","ADJX"),("VVINF","NN")]
                         
# Alle Templates in einer Liste
all_templates = [templates_NN_NN, templates_NN_ADJX, templates_NN_VVINF,
                templates_ADJX_ADJX, templates_ADJX_NN, templates_ADJX_VVINF,
                templates_VVINF_VVINF, templates_VVINF_ADJX, templates_VVINF_NN]

# Liste der Templates sortiert nach Rang:
# Liste hat zwei Elemente:
# - 0: Liste der Templates für Vers 1 und 2
# - 1: Liste der Templates für Vers 3 und 4
templates_list = ([vers_temp[0][2:]+"\n"+vers_temp[1] for vers_temp in [[template for template in templates.split("\n")[:2]] for templates in all_templates]],[vers_temp[0][2:]+"\n"+vers_temp[1] for vers_temp in [[template for template in templates.split("\n")[2:]] for templates in all_templates]])

# Liste mit Wörtern erstellen, die in Templates vorkommen
template_words = []
for template in all_templates:
    for word in template.split():
        if word.lower() == word and word not in ["1","2"] and strip_punctuation(word) not in template_words:
            template_words.append(strip_punctuation(word))