# -*- coding: utf-8 -*-

"""
In diesem Modul werden Korpora des Typ 1 verarbeitet und Dateien mit Wortlisten erstellt.

Verwendete Ressourcen:
- Wortlisten, abgerufen auf: - http://www.kuuuk.com/plural-lexikon-singular.htm
                             - http://deutsch-als-fremdsprache-grammatik.de/Wortkarteien/html_pdf/substantive3.htm
                             - https://de.wiktionary.org/wiki/Verzeichnis:Deutsch/W%C3%B6rter_mit_%C3%9F
- Vornamen_Koeln_2017.csv (https://github.com/fxnn/vornamen)
- nouns.csv (https://offenedaten-koeln.de/dataset/vornamen)

Erstellte Dateien:
- ss_words.txt
- TaggedNouns.txt
"""

# re
import re

##########################################
# Eigene Wortlisten nach Genus sortiert
##########################################

# Maskuline Wörter
masc_words_own = ['Test', 'Rahmen', 'Hafen', 'Penis', 'Wert', 'Samen', 'Riemen', 'Deutsche', 'Raum', 'Rost', 'Irrtum', 'Gott', 'Po', 'Ranzen', 'Kasten', 'Gedanke', 'Hippie', 'Wein', 'Stein', 'Tote', 'Salto', 'Bösewicht', 'Daene', 'Loewe', 'Krake', 'eine', 'Popo', 'Ast', 'August', 'Baum', 'Drachen', 'Durst', 'Garten', 'Geburtstag', 'Hut', 'Kaffee', 'Kakao', 'Kuchen', 'Markt', 'Ofen', 'Opa', 'Papagei', 'Saft', 'Schlitten', 'Schwan', 'See', 'Specht', 'Sport', 'Tee', 'Traum', 'Tropfen', 'Unterricht', 'Wagen', 'Wind', 'Zoo', 'Gefrierschrank', 'Ofen', 'Gefrierbeutel', 'Schneebesen', 'Topflappen', 'Besen', 'Rest', 'Spüllappen', 'Mandelstift', 'Bauer', 'Bote', 'Bursche', 'Erbe', 'Experte', 'Fürst', 'Genosse', 'Graf', 'Held', 'Herr', 'Hirte', 'Insasse', 'Jude', 'Junge', 'Kamerad', 'Knabe', 'Kollege', 'Kunde', 'Mensch', 'Nachbar', 'Nachkomme', 'Neffe', 'Prinz', 'Rebell', 'Riese', 'Satellit', 'Sklave', 'Soldat', 'Zeuge', 'Affe', 'Bär', 'Bulle', 'Hase', 'Löwe', 'Ochse', 'Rabe', 'Brite', 'Bulgare', 'Däne', 'Franzose', 'Finne', 'Grieche', 'Ire', 'Schotte', 'Pole', 'Portugiese', 'Rumäne', 'Russe', 'Schwede', 'Slowake', 'Tscheche', 'Türke', 'Ungar', 'Asiate', 'Friede', 'Glaube', 'Name', 'Morgen', 'Sommer', 'Winter', 'Frühling', 'Herbst', 'Regen', 'Schnee', 'Tau', 'Sturm', 'Unfug', 'Schrott', 'Idiot', 'Niedergang', 'Sturz', 'Verzicht', 'Diebstahl', 'Andrang', 'Anspruch', 'Anstieg', 'Applaus', 'Aufschwung', 'Auftrag', 'Auftrieb', 'Aufwärtstrend', 'Beifall', 'Beifallsruf', 'Beitritt', 'Bonus', 'Champion', 'Charme', 'Einkauf', 'Entschluß', 'Erfolg', 'Favorit', 'Festakt', 'Flair', 'Fleiß', 'Fortschritt', 'Frieden', 'Genuß', 'Gewinn', 'Glückwunsch', 'Hochruf', 'Höhepunkt', 'Intellekt', 'Intelligenz', 'Jubel', 'Komfort', 'Kompromiss', 'Konjunkturaufschwung', 'Konsens', 'Lohn', 'Mut', 'Nutzen', 'Profit', 'Reichtum', 'Respekt', 'Ruhm', 'Schatz', 'Schwung', 'Siegeszug', 'Spaß', 'Sprung', 'Steigflug', 'Stil', 'Superlativ', 'Trost', 'Umbruch', 'Verband', 'Verbund', 'Verdienst', 'Visionär', 'Vorteil', 'Witz', 'Zenit', 'Zusammenhalt', 'Abschuß', 'Abschuss', 'Abstoß', 'Absturz', 'Abwärtstrend', 'Alarm', 'Alptraum', 'Albtraum', 'Amateur', 'Angriff', 'Aufruhr', 'Aufschrei', 'Aufstand', 'Ausbruch', 'Bankrott', 'Bedürftige', 'Befall', 'Beschäftigungslose', 'Betrug', 'Crash', 'Defekt', 'Dreck', 'Drift', 'Ehebruch', 'Einbruch', 'Einschlag', 'Ekel', 'Fehlkauf', 'Fehltritt', 'Feind', 'Geizhals', 'Geizkragen', 'Gewalttätige', 'Groll', 'Hinterhalt', 'Hungertod', 'Jähzorn', 'Kollaps', 'Konflikt', 'Konjunkturrückgang', 'Konkurs', 'Krach', 'Krüppel', 'Kurseinbruch', 'Leichtsinn', 'Leidende', 'Melodrama', 'Missbrauch', 'Misstrauensantrag', 'Neid', 'Neustart', 'Notstand', 'Protest', 'Reinfall', 'Rivale', 'Ruin', 'Rutsch', 'Rückfall', 'Rückgang', 'Rückschritt', 'Rückstand', 'Rücktritt', 'Rückzug', 'Schaden', 'Schlachtfeld', 'Schmuggel', 'Schock', 'Schreck', 'Schräglauf', 'Schubs', 'Schurke', 'Skandal', 'Spott', 'Stau', 'Stoß', 'Streit', 'Stress', 'Sündenbock', 'Todesfall', 'Totschlag', 'Trott', 'Umtausch', 'Unfall', 'Fön', 'Unmut', 'Unsinn', 'Untergang', 'Verdacht', 'Verdächtige', 'Verfall', 'Verlust', 'Vorwurf', 'Wahnsinn', 'Wermutstropfen', 'Wertverlust', 'Widerruf', 'Widerspruch', 'Zusammenbruch', 'Zusammenstoß', 'Zwang','Abrutsch', 'Vertrag', 'Sprengstoff', 'Anteil', 'Konkurrenzkampf', 'Ausfall', 'Dieb', 'Stillstand', 'Verstand', 'Anstand', 'Vorwand','Besitz', 'Zweifel', 'Raub', 'Trugschluss', 'Freispruch', 'Abfall', 'Dissens', 'Überschuß', 'Glamour', 'Krieg', 'Fluch', 'Arroganz', 'Kauf', 'Makel', 'Genuss', 'Notfall', 'Glanz', 'Teufelskreis', 'Bund', 'Schmerz', 'Abstieg', 'insturz', 'Mangel', 'Narr', 'Abschluß', 'Keim', 'Brand', 'Kopfschmerz', 'Kampf', 'Schirmherr', 'Triumph', 'Boom', 'Hass', 'Schmuck', 'Streik', 'Schlag', 'Zensur', 'Gestank', 'Wohlstand', 'Mord', 'Schmutz', 'Hohn', 'Verstoß', 'Zuschuß', 'Nachteil', 'Geiz', 'Bruch', 'Abgrund', 'Dummkopf', 'Überfluß', 'Zorn', 'Schwund', 'Schutz', 'Tod', 'Abriss', 'Stolz', 'Dussel', 'Safe', 'Aufstieg', 'Freund', 'Preissturz', 'Ertrag', 'Müll', 'Zoll', 'Start', 'Anwalt','ARD','ICE']
# Feminine Wörter
fem_words_own = ['Kammer', 'Lady', 'Kleinen', 'Nadel', 'Tendenz', 'Qual', 'Ananas', 'Cd', 'CD', 'Hantel', 'Wahl', 'Lok', 'Pappel', 'Story', 'Agentur', 'Ampel', 'Nudel', 'Bahn', 'Bank', 'Butter', 'Eltern', 'Feder', 'Frau', 'Gans', 'Gefahr', 'Hand', 'Insel', 'Jagd', 'Kartoffel', 'Kuh', 'Leiter', 'Maus', 'Milch', 'Mutter', 'Nuss', 'Saat', 'Schwester', 'Tafel', 'Tochter', 'Tür', 'Uhr', 'Wand', 'Zahl', 'Zwiebel', 'Gabel', 'Korb', 'Küchenuhr', 'Rührschüssel', 'Schüssel', 'Zutaten', 'Butter', 'Milch', 'Redundanz', 'Cleverness', 'Erlaubnis', 'Exzellenz', 'Feier', 'Heirat', 'Büroklammer', 'Kompetenz', 'Konsistenz', 'Moral', 'Potenz', 'Präferenz', 'Stütze', 'Toleranz', 'Wohltat', 'Ambivalenz', 'Besorgnis', 'Düsternis', 'Frust', 'Inkompetenz', 'Inkonsistenz', 'Inkonsequenz', 'Konkurrenz', 'Lebensgefahr', 'Reparatur', 'Schlitterbahn', 'Turbulenz', 'Akzeptanz', 'Kur', 'Abfuhr', 'Relevanz', 'Dynamik', 'Kritik', 'Korrektur', 'Ineffizienz', 'Panik', 'Kachel', 'List', "Mimi", 'Krankenschwester', 'Hand','DDR', 'DNA', 'DVD','FAZ','GEZ','NASA','PS','UNO','VHS','WM']
# Neutrale Wörter
neut_words_own = ['Leben', 'Kinn', 'Feuerzeug', 'Quiz', 'Arsenal', 'Kaenguru', 'Geraet', 'Fax', 'Wrack', 'Bein', 'Handy', 'Rudel', 'Joghurt', 'Kabel', 'Lexikon', 'Schnitzel', 'Wort', 'Gold', 'Känguru', 'Gummi', 'Knie', 'Jogurt', 'Loch', 'Baby', 'Joint', 'Auge', 'Beet', 'Bett', 'Bild', 'Blatt', 'Boot', 'Brett', 'Brot', 'Buch', 'Dach', 'Dorf', 'Ei', 'Ende', 'Fahrrad', 'Fahrzeug', 'Fenster', 'Fest', 'Feuer', 'Flugzeug', 'Frühstück', 'Gedicht', 'Gemüse', 'Gewitter', 'Glas', 'Glück', 'Gras', 'Haar', 'Haus', 'Heft', 'Hemd', 'Herz', 'Holz', 'Huhn', 'Jahr', 'Kamel', 'Kissen', 'Kleid', 'Krokodil', 'Land', 'Licht', 'Lied', 'Meer', 'Mehl', 'Messer', 'Nest', 'Obst', 'Ohr', 'Paket', 'Papier', 'Pferd', 'Rad', 'Rätsel', 'Regal', 'Salz', 'Schiff', 'Schloss', 'Spiel', 'Tal', 'Telefon', 'Tier', 'Tuch', 'Vesper', 'Wasser', 'Wetter', 'Xylolofon', 'Ypsilon', 'Zelt', 'Zimmer', 'Kochfeld', 'Ofenblech', 'Ofengitter', 'Backpapier', 'Besteck', 'Brett', 'Glas', 'Messer', 'Nudelholz', 'Sieb', 'Kehrblech', 'Backpulver', 'Brot', 'Ei', 'Fleisch', 'Kakaopulver', 'Marzipan', 'Mehl', 'Öl', 'Paniermehl', 'Püree', 'Salz', 'Wasser', 'Schwein', 'Charisma', 'Angebot', 'Ausbau', 'Benefiz', 'Comeback', 'Eigenkapital', 'Engagement', 'Gedenken', 'Genie', 'Highlight', 'Hochdruckgebiet', 'Hurra', 'Hurrageschrei', 'Interesse', 'Lob', 'Mitgefühl', 'Prestige', 'Privileg', 'Rückgrat', 'Talent', 'Upgrade', 'Vertrauen', 'Wohlergehen', 'Wohlgefallen', 'Wohlwollen', 'Wunder', 'Spektakel', 'Arschloch', 'Defizit', 'Desaster', 'Desinteresse', 'Dilemma', 'Doppelspiel', 'Durcheinander', 'Elend', 'Fehlverhalten', 'Gedränge', 'Gift', 'Handgemenge', 'Handikap', 'Handicap', 'Klischee', 'Massaker', 'Missgeschick', 'Misstrauen', 'Problem', 'Sterben', 'Strafverfahren', 'Tabu', 'Trauma', 'Unbehagen', 'Unglück', 'Unrecht', 'Verbot', 'Versagen', 'Übergewicht', 'Übermaß', 'Geschick', 'Vorurteil', 'Pech', 'Bußgeld', 'Geschick', 'Meisterwerk', 'Leid', 'Schadensbild', 'Paradies', 'Trübsal', 'Effizienz', 'Geschenk', 'Schuld', 'Scheitern', 'Ziel', 'Osterei', 'Fruehstuecksei', 'Lama', 'BSE', 'KZ', 'LSD', 'RPG', 'SOS', 'WC']

####################################################################################
# Liste mit Wörtern, die ß enthalten. Kopiert von:
# https://de.wiktionary.org/wiki/Verzeichnis:Deutsch/W%C3%B6rter_mit_%C3%9F
####################################################################################

ss_wiktionary = ['Anmaßung', 'Ausmaß', 'Außerachtlassung', 'Beißschiene', 'Blöße', 'Buße', 'Bußgeld', 'Bärbeißigkeit', 'Büßer', 'Dreißiger', 'Einflößung', 'Entblößung', 'Fleiß', 'Floß', 'Flößer', 'Fraß', 'Fuß', 'Füßchen', 'Gefrieß', 'Gefäß', 'Geheiß', 'Geiß', 'Geißel', 'Geißelung', 'Geschmeiß', 'Gesäß', 'Gießen', 'Gliedmaße', 'Grieß', 'Gruß', 'Kloß', 'Klößchen', 'Kreißsaal', 'Litfaßsäule', 'Lößboden', 'Maß', 'Maßnahme', 'Maßstab', 'Meißen', 'Muße', 'Neiße', 'Nießnutz', 'Nutznießer', 'Preußen', 'Reuße', 'Ruß', 'Scheiße', 'Schließer', 'Schließfach', 'Schließung', 'Schmeißer', 'Schoß', 'Schultheiß', 'Schweiß', 'Schweißung', 'Soße', 'Spaß', 'Spieß', 'Spießer', 'Spleiß', 'Späßchen', 'Steiß', 'Stoß', 'Strauß', 'Straße', 'Sträßchen', 'Stößchen', 'Stößel', 'Süße', 'Süßigkeit', 'Süßkraut', 'Verbüßung', 'Verheißung', 'Verschleiß', 'anmaßen', 'anschließend', 'aufspießen', 'ausschließlich', 'außen', 'außer', 'außerdem', 'barfüßig', 'befleißigen', 'beißen', 'beließ', 'bemaßen', 'bemüßigen', 'bespaßen', 'bloß', 'bußfertig', 'bärbeißig', 'büßen', 'dermaßen', 'draußen', 'draußen', 'dreißig', 'einschließlich', 'entblößen', 'entäußern', 'ersprießlich', 'fleiß', 'fleißig', 'fließen', 'flößen', 'fuß', 'fußen', 'gefraeßig', 'gefräßig', 'geißeln', 'gemäß', 'genießbar', 'genießen', 'geschweißt', 'geäußert', 'gießen', 'gleißend', 'groeßer', 'groß', 'groß', 'größte', 'grüßen', 'heiß', 'heiß', 'heißa', 'heißen', 'kreißen', 'maßen', 'maßgeblich', 'meißeln', 'mutmaßlich', 'mäßig', 'müßig', 'preußisch', 'reißen', 'reißend', 'scheißen', 'scheußlich', 'scheußlich', 'schießen', 'schleißen', 'schließbar', 'schließen', 'schließlich', 'schmeißen', 'schmeißen', 'schweißen', 'schweißgebadet', 'spaßeshalber', 'spaßig', 'spaßig', 'spießen', 'spießig', 'spießig', 'spleißen', 'sprießen', 'steißwärts', 'stoßen', 'stoßen', 'sueß', 'süß', 'verdrießen', 'verdrießlich', 'vergroeßert', 'verheißen', 'verhieß', 'verschleißen', 'verschließen', 'verschweißen', 'veräußern', 'weiß', 'weiß', 'zerbeißen', 'zerschleißen', 'zuäußerst', 'zweckmaeßig', 'Äußerlichkeit', 'Äußerung', 'äußeres', 'äußerlich', 'äußerln', 'äußern', 'äußerst']

############################################################
# Liste mit Vornamen erstellen
# Hierzu dient eine CSV-Datei
# bereitgestellt von: https://offenedaten-koeln.de/dataset/vornamen
# Datei enthält drei Spalten:
# Vorname; Anzahl; Geschlecht
############################################################

# Datei öffnen
names_open = open("Vornamen_Koeln_2017.csv", encoding="UTF-8")
# Datei einlesen
names_read = names_open.read()
# an Zeilen umbruch spliten, jedes Element splitten
names_split = [name.split(",") for name in names_read.split("\n") if len(name.split(",")) == 3]
# Liste mit männlichen bzw. weiblichen Namen erstellen, wenn sie öfter als einmal vorkommen
male_names = [name[0] for name in names_split[1:] if int(name[1]) > 1 and name[2] == "m"]
female_names = [name[0] for name in names_split[1:] if int(name[1]) > 1 and name[2] == "w"]
# Datei schließen
names_open.close()


#######################################################################################
# Korpus mit deutschen Nomen, getaggt mit grammatikalischen Einheiten
# zugänglich auf: https://github.com/gambolputty/german-nouns
# Im Folgenden werden Listen mit Grundformen von Nomen in vier Listen gespeichert:
# Singular(maskulin,feminin,neutrum), Plural
# relevante Spalten:
# 1 POS
# 2 genus
# 7 nominativ singular
# 16 nominativ plural
#######################################################################################

# Datei öffnen
nouns_open = open("nouns.csv", encoding="UTF-8")
# Datei Einlesen
nouns_read = nouns_open.read()
# In Spalten und Zeilen aufteilen
nouns_split = [toks.split(",") for toks in nouns_read.split("\n")]
# maskuline Wörter
masc_words_corpus = []
# feminine Wörter
fem_words_corpus = []
# neutrale Wörter
neut_words_corpus = []
# Pluralformen
plural_words = []
# über Liste mit nomen iterieren
for noun in nouns_split:
    # Wenn lang genug und POS Substativ ist
    if len(noun) > 15 and noun[1] == "Substantiv":
        # masc
        if noun[2] == "m" and len(noun[7]) != 0 and re.sub(r"[\.\,\!\?\:\;\"\'\#\(\)\-\&\%\§]", "", noun[7]) == noun[7]:
            masc_words_corpus.append(noun[7])
        # fem
        if noun[2] == "f" and len(noun[7]) != 0 and re.sub(r"[\.\,\!\?\:\;\"\'\#\(\)\-\&\%\§]", "", noun[7]) == noun[7]:
            fem_words_corpus.append(noun[7])
        # neut
        if noun[2] == "n" and len(noun[7]) != 0 and re.sub(r"[\.\,\!\?\:\;\"\'\#\(\)\-\&\%\§]", "", noun[7]) == noun[7]:
            neut_words_corpus.append(noun[7])
        # plural
        if len(noun[16]) != 0 and re.sub(r"[\.\,\!\?\:\;\"\'\#\(\)\-\&\%\§]", "", noun[16]) == noun[16]:
            plural_words.append(noun[16])
# Datei schließen
nouns_open.close()
            
##############################
#  Wortlisten zusammenfügen  #
##############################

# Maskulin
masc_words = list(set(masc_words_own+masc_words_corpus+male_names))
# Feminin
fem_words = list(set(fem_words_own+fem_words_corpus+female_names))
# Neutral
neut_words = list(set(neut_words_own+neut_words_corpus))


###################################################
#  Identifizierte Wörter in eine Datei schreiben  #
###################################################

# Jedes Wort aus den vier erstellten Nomenlisten wird mit entsprechendem
# Tag (MASC,FEM,NEUT,PL) in eine Datei namens TaggedNouns.txt geschrieben.
TaggedNouns_file = open("TaggedNouns.txt", "w", encoding="UTF-8")
for word in masc_words:
    if word != "":
        TaggedNouns_file.write(word+"\tMASC\n")
for word in fem_words:
    if word != "":
        TaggedNouns_file.write(word+"\tFEM\n")
for word in neut_words:
    if word != "":
        TaggedNouns_file.write(word+"\tNEUT\n")      
for word in plural_words:
    if word != "":
        TaggedNouns_file.write(word+"\tPL\n") 
TaggedNouns_file.close


###################################################
#  Datei mit Wörtern erstellen, die ß enthalten   #
###################################################

# Liste erstellen mit Wörtern, die ß enthalten (Aus allen Nomenlisten)
ss_nouns = [word for word in masc_words+fem_words+neut_words+plural_words if "ß" in word]
# ß-Listen zusammenfügen
ss_all = ss_wiktionary+ss_nouns
# Datei "ss_words.txt" erstellen
ss_file = open("ss_words.txt", "w", encoding="UTF-8")
# Jedes Wort in die Datei schreiben (von Zeilenumbruch getrennt)
for word in ss_all:
    ss_file.write(word+"\n")
# Datei schließen
ss_file.close()